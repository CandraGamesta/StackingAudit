const { expectRevert, time } = require('@openzeppelin/test-helpers');
const { inTransaction } = require('@openzeppelin/test-helpers/src/expectEvent');
const { BN, web3 } = require('@openzeppelin/test-helpers/src/setup')
const helper = require("./helpers/truffleTestHelper");
const CrushToken = artifacts.require('DrugzToken');
const BitcrushStaking = artifacts.require('DopeWarzStaking');

contract('Bitcrush', ([alice, bob, carol, robert, dev ,minter, tom, terry, jerry]) => {
    
    const toWei = ( number ) => {
        return web3.utils.toBN(""+number).mul( web3.utils.toBN('10').pow( web3.utils.toBN('18') ) )
    }
    const fromWei = ( input ) => {
        return web3.utils.fromWei( input )
    }

    const waitForBlocks = async blocksToWait => {
        for( i = 0; i< blocksToWait; i++)
            await helper.advanceTimeAndBlock(60)
    }

    const logSection = text => {
        console.log('-------------------------')
        console.log(text)
        console.log('-------------------------')
    }

    beforeEach(async () => {
        this.crush = await CrushToken.new({ from: minter });
        this.staking = await BitcrushStaking.new(this.crush.address, toWei(1) ,dev, { from: minter },);
        

        await this.crush.mint(minter, toWei(1000000), {from : minter});
        await this.crush.mint(alice, toWei(10000), {from : minter});
        await this.crush.mint(bob, toWei(10000), {from : minter});
        await this.crush.mint(robert, toWei(10000), {from : minter});
        await this.crush.mint(carol, toWei(10000), {from : minter});
        await this.crush.mint(tom, toWei(10000), {from : minter});
        await this.crush.mint(terry, toWei(10000), {from : minter});
        await this.crush.mint(jerry, toWei(10000), {from : minter});
        
        await this.crush.approve(this.staking.address, toWei(30000000), {from : minter});
        await this.staking.addRewardToPool( toWei(20000), {from : minter});

        
        
        
        await this.crush.approve( this.staking.address, toWei(30000000), {from: alice})
        await this.crush.approve( this.staking.address, toWei(30000000), {from: bob})
        await this.crush.approve( this.staking.address, toWei(30000000), {from: carol})
        await this.crush.approve( this.staking.address, toWei(30000000), {from: dev})
        await this.crush.approve( this.staking.address, toWei(30000000), {from: robert})
        await this.crush.approve( this.staking.address, toWei(30000000), {from: minter})
        await this.crush.approve( this.staking.address, toWei(30000000), {from: tom})
        await this.crush.approve( this.staking.address, toWei(30000000), {from: terry})
        await this.crush.approve( this.staking.address, toWei(30000000), {from: jerry})

        this.logStakes = async() => {
            let aliceStakings = await this.staking.stakings(alice)
            let bobStakings = await this.staking.stakings(bob)
            let carolStakings = await this.staking.stakings(carol)
            let tomStakings = await this.staking.stakings(tom)
            let terryStakings = await this.staking.stakings(terry)
            let jerryStakings = await this.staking.stakings(jerry)
            let currentBlock = (await web3.eth.getBlock('latest')).number
            let aliceReward = await this.staking.pendingReward(alice)
            let bobReward = await this.staking.pendingReward(bob)
            let tomReward = await this.staking.pendingReward(tom)
            let carolReward = await this.staking.pendingReward(carol)
            let terryReward = await this.staking.pendingReward(terry)
            let jerryReward = await this.staking.pendingReward(jerry)
            let pool = fromWei(await this.staking.totalPool())
            
            console.log( { 
                currentBlock,
                
                pool,
                a: {
                    reward: fromWei(aliceReward.toString()),
                    staked: fromWei(aliceStakings.stakedAmount.toString()),
                },
                b: {
                    reward: fromWei(bobReward.toString()),
                    staked: fromWei(bobStakings.stakedAmount.toString()),
                },
                t: {
                    reward: fromWei(tomReward.toString()),
                    staked: fromWei(tomStakings.stakedAmount.toString()),
                },
                ter: {
                    reward: fromWei(terryReward.toString()),
                    staked: fromWei(terryStakings.stakedAmount.toString()),
                },
                j: {
                    reward: fromWei(jerryReward.toString()),
                    staked: fromWei(jerryStakings.stakedAmount.toString()),
                },
                c: {
                    reward: fromWei(carolReward.toString()),
                    staked: fromWei(carolStakings.stakedAmount.toString()),
                },
                
            })
        }
    });
    
    

    it("Check of multiple scenarios", async()=>{
        const staked = toWei(200)
        await this.staking.enterStaking( staked ,{ from: alice})
        await this.staking.enterStaking( staked ,{ from: bob })
        await this.staking.enterStaking( staked ,{ from: tom })
        await this.staking.enterStaking( staked ,{ from: terry })
        await this.staking.enterStaking( staked ,{ from: jerry })
        await this.staking.enterStaking( staked ,{ from: carol })
        logSection('start')
        await this.logStakes()
        await waitForBlocks(10)
        await this.logStakes()
        logSection('compound1')
        await this.staking.compound({from: carol})
        await this.logStakes()
        await waitForBlocks(10)
        await this.logStakes()
        logSection('compound2')
        await this.staking.compound({from: alice})
        await this.logStakes()
        await waitForBlocks(10)
        await this.logStakes()
        logSection('compound3')
        await this.staking.compound({from: bob})
        await this.logStakes()
        await waitForBlocks(10)
        await this.logStakes()
        logSection('compound4')
        await this.staking.compound({from: tom})
        await this.logStakes()
        await waitForBlocks(10)
        await this.logStakes()
        logSection('compound5')
        await this.staking.compound({from: terry})
        await this.logStakes()
    })

});