const Blackmarket = artifacts.require("Blackmarket");
const DopeWarzStaking = artifacts.require("DopeWarzStaking");
const DrugzToken = artifacts.require("DrugzToken");

module.exports = async function (deployer) {
    //await deployer.deploy(DrugzToken);
    //let drugInstance = await DrugzToken.deployed();
    await deployer.deploy(DopeWarzStaking, "0x27e2A0E643c7f17959F84C345d2123B77bbd412c", 1000000000000000000n, "0x9b9315D667be52f0B4036E79253D30AC05040f94");
    let stakingInstance = await DopeWarzStaking.deployed();

    //for testnet
    //await drugInstance.mint("0x0E5De84bFC1A9799a0FdA4eF0Bd13b6A20e97d89",999999999999999999999999n);
    //await drugInstance.approve(stakingInstance.address, 150000000000000000000n);
    //await stakingInstance.addRewardToPool(150000000000000000000n);



    
}