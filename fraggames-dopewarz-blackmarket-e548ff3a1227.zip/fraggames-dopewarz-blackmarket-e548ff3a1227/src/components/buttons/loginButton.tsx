import React from "react";
import { useAuth } from "../hooks/web3Auth";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
export default function LoginButton() {
  const { login } = useAuth();

  return (
    <>
      <Tooltip title="Metamask Extension Required">
        <Button color="primary" variant="outlined" onClick={() => login()} sx={{backgroundColor: "#046cfc", border: "none", borderRadius: 0, height: "45px", width: "100px", marginTop : 0}}>
          Login
        </Button>
      </Tooltip>
    </>
  );
}
