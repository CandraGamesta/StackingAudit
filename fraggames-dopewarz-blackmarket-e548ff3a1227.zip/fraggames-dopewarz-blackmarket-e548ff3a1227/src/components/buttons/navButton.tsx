import Button from "@mui/material/Button";

export default function NavButton(props: any) {
  var iconStyle = {
    opacity: 0.75,
  };
  console.log(props.currentPage.route, props.location.pathname);
  if (props.currentPage.route === props.location.pathname) {
    console.log("route matched");
    return (
      <Button
        href={props.currentPage.route}
        sx={{
          fontFamily: "ThaleahFat",
          fontSize: "20px",
          my: 2,
          color: "#8600d4",
          borderBottom: "2px solid #8600d4",
          borderRadius: "0",
        }}
        startIcon={<img src={props.currentPage.iconSelected} />}
      >
        {props.currentPage.name}
      </Button>
    );
  } else {
    console.log("route not matched");
    return (
      <Button
        href={props.currentPage.route}
        sx={{
          fontFamily: "ThaleahFat",
          fontSize: "20px",
          my: 2,
          color: "text.secondary",
        }}
        startIcon={<img src={props.currentPage.iconUnselected} />}
      >
        {props.currentPage.name}
      </Button>
    );
  }
}
