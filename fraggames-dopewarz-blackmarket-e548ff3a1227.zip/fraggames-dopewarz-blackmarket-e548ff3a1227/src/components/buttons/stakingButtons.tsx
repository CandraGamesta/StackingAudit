import React from "react";
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import IconButton from '@mui/material/IconButton';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
export default function StakingButtons(props: any) {
  if (!props.loaded) {
    return (
      <Grid item md={12} sm={12} xs={12}>
        <Button
          variant="outlined"
          onClick={() => {}}
          disabled
          sx={{
            backgroundColor: "#8600d4",
            width: "60%",
            border: "none",
            mx: "20%",
            mt: 1,
            fontFamily: "ThaleahFat",
            fontSize: "22px",
            p: 0,
            height: "40%",
          }}
        >
          Loading
        </Button>
        <Divider sx={{ pt: 2, mb: 1, borderColor: "#303442" }} />
      </Grid>
    );
  } else if (props.loaded && !props.isApproved) {
    return (
      <Grid item md={12} sm={12} xs={12}>
        <Button
          variant="outlined"
          onClick={() => {
            props.approve();
          }}
          sx={{
            backgroundColor: "#8600d4",
            width: "60%",
            border: "none",
            mx: "20%",
            mt: 1,
            fontFamily: "ThaleahFat",
            fontSize: "22px",
            p: 0,
            height: "40%",
          }}
        >
          Approve
        </Button>
        <Divider sx={{ pt: 2, mb: 1, borderColor: "#303442" }} />
      </Grid>
    );
  } else if (props.loaded && props.isApproved) {
    return (
      <>
        <Grid item md={6} sm={6} xs={6}>
          <Button
            variant="outlined"
            onClick={() => {
              props.compound();
            }}
            sx={{
              backgroundColor: "#8600d4",
              width: "90%",
              border: "none",
              mx : "10%",
              mt: 1,
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              p: 0,
              height: "40%",
            }}
            disabled={parseInt(props.stakedAmount) === 0}
          >
            Compound
          </Button>
          <Divider sx={{ pt: 2, mb: 1, borderColor: "#303442" }} />
        </Grid>
        <Grid item md={6} sm={6} xs={6}>
          <Button
            variant="outlined"
            onClick={() => {
              props.harvest();
            }}
            sx={{
              backgroundColor: "#8600d4",
              width: "90%",
              border: "none",
              mx : "10%",
              mt: 1,
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              p: 0,
              height: "40%",
            }}
            disabled={parseInt(props.stakedAmount) === 0}
          >
            Harvest
          </Button>
          <Divider sx={{ pt: 2, mb: 1, borderColor: "#303442" }} />
        </Grid>
        <Grid item md={6} sm={6} xs={6}>
          <Button
            variant="outlined"
            startIcon={<AddIcon />}
            onClick={() => {
              props.deposit(true);
            }}
            sx={{
              backgroundColor: "#8600d4",
              width: "90%",
              border: "none",
              mx : "10%",
              mt: 1,
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              p: 0,
              height: "40%",
            }}
            
          >
            Deposit
          </Button>
          <Divider sx={{ pt: 2, mb: 1, borderColor: "#303442" }} />
        </Grid>
        <Grid item md={6} sm={6} xs={6}>
          <Button
            variant="outlined"
            startIcon={<RemoveIcon />}
            onClick={() => {
              props.withdraw(10);
            }}
            sx={{
              backgroundColor: "#8600d4",
              width: "90%",
              border: "none",
              mx : "10%",
              mt: 1,
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              p: 0,
              height: "40%",
            }}
            disabled={parseInt(props.stakedAmount) === 0}
          >
            Withdraw
          </Button>
          <Divider sx={{ pt: 2, mb: 1, borderColor: "#303442" }} />
        </Grid>

      </>
    );
  }else {
      
      return (<>no matching cirteria</>)
  }
}
