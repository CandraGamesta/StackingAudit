import React from 'react'
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
export default function StakingDepositDialogue(props: any) {
    
  return (
    <>
      <Dialog
        open={props.openStake}
        onClose={props.handleCloseStake}
        sx={{
          "& .MuiDialog-paper": {
            backgroundColor: "#06070b",
            border: "1px solid grey",
          },
        }}
      >
        <DialogTitle>Deposit Drugz</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Please enter the amount you wish to deposit
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            id="name"
            label="Price"
            type="number"
            fullWidth
            variant="outlined"
            value={props.amount}
            
            onChange={props.handleAmountChange}
          />
        </DialogContent>
        <DialogActions>
          <Button
            onClick={props.handleCloseStake}
            variant="outlined"
            color="error"
            sx={{ margin: "10px" }}
          >
            Cancel
          </Button>
          <Button
            onClick={props.action}
            variant="outlined"
            color="success"
            sx={{ margin: "10px" }}
          >
            Deposit
          </Button>
        </DialogActions>
      </Dialog>
    </>

  )
}
