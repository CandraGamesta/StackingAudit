import React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Slide from "@mui/material/Slide";
import { useHistory } from "react-router-dom";
const Transition: any = React.forwardRef(function Transition(
  props: any,
  ref: any
) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function OrderSuccess(props: any) {
  let history = useHistory();

  const handleClickOpen = () => {
    props.setOpen(true);
  };

  const handleClose = () => {
    props.setOpen(false);
  };
  const goToActivity = () => {
    history.push("/accounthistory");
  };

  return (
    <div>
      <Dialog
        open={props.open}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClose}
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle
          sx={{
            border: `1px solid #0b0c14`,
            backgroundColor: "#040508",
            color: "white",
          }}
        >
          {"Congratulations!"}
        </DialogTitle>
        <DialogContent
          sx={{
            border: `1px solid #0b0c14`,
            backgroundColor: "#040508",
            color: "white",
          }}
        >
          <DialogContentText id="alert-dialog-slide-description">
            Transaction Submitted Succesfully
          </DialogContentText>
        </DialogContent>
        <DialogActions
          sx={{
            border: `1px solid #0b0c14`,
            backgroundColor: "#040508",
            color: "white",
          }}
        >
          <Button variant="outlined" onClick={handleClose}>
            Close
          </Button>
          <Button variant="outlined" onClick={goToActivity}>
            Go To My Activity
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
