import React from "react";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
export default function EditListing(props: any) {
  return (
    <>
      <Dialog
        open={props.openListForSale}
        onClose={props.handleCloseListForSale}
        sx={{
          "& .MuiDialog-paper": {
            backgroundColor: "#06070b",
            border: "1px solid grey",
          },
        }}
      >
        <DialogTitle>List for sale</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Please enter the price to list the NFT for Sale
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            id="name"
            label="Price"
            type="number"
            fullWidth
            variant="outlined"
            value={props.listingPrice}
            onChange={props.handlePriceChange}
          />
        </DialogContent>
        <DialogActions>
          <Button
            onClick={props.handleCloseListForSale}
            variant="outlined"
            color="error"
            sx={{ margin: "10px" }}
          >
            Cancel
          </Button>
          <Button
            onClick={props.action}
            variant="outlined"
            color="success"
            sx={{ margin: "10px" }}
          >
            List
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
