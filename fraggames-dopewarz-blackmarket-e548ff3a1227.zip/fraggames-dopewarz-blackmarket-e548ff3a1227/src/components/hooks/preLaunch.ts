
const PreLaunch : boolean = true;

export const useIsPreLaunchEnabled   = () => {
    return PreLaunch;
}