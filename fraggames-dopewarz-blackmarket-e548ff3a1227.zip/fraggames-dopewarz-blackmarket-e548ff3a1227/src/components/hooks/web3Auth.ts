import { useCallback } from 'react'
import { useWeb3React } from '@web3-react/core'
import { InjectedConnector,  UserRejectedRequestError as UserRejectedRequestErrorInjected } from '@web3-react/injected-connector'
import { useEffect, useState } from 'react'
import Web3 from 'web3'
const validChains = [56,97] // BSC Mainnet and Testnet
export const useAuth = () => {
  
  const { activate, deactivate, account, chainId } = useWeb3React()
  
  const login = useCallback(() => {
    const connector = new InjectedConnector({ supportedChainIds: validChains})
    if(connector)
      activate(connector, async(error) =>{
        console.log('failed activation',error)
        if(error)
          setTimeout( () => window.localStorage.setItem('connectorId', ""), 1000)
      })
      .then( () => window.localStorage.setItem('connectorId', "injected" ))
  },[activate])

  const logout = useCallback(() => {
    deactivate()
    window.localStorage.setItem('connectorId', '')
  }, [deactivate])

  return { login, logout, account, chainId }
}
// Automatically try to login if use has previously logged in
export const useEagerConnect = () => {

  const { login } = useAuth()
  
  useEffect(()=>{
    
    const connector = window.localStorage.getItem('connectorId');
    if(!connector) return
    login()

  }, [login])
}
const web3 = new Web3(Web3.givenProvider)
// easy import of a contract to interact with
export function useContract(abi: any, address: string): ContractHandles{
  const { chainId } = useWeb3React()
  const [contract, setContract] = useState(() => [56, 97].indexOf(chainId || 0)> -1 && address ? new web3.eth.Contract(abi,address) : null)
  
  useEffect( () => {
    chainId && setContract( () => [56, 97].indexOf(chainId || 0)> -1 && address ? new web3.eth.Contract(abi,address) : null )
  },[chainId,abi,address])
  console.log("contract?.methods");
  console.log(contract?.methods);
  return { contract, methods: contract?.methods || null, web3 }
}

type ContractHandles = {
  contract: any,
  methods: any | null,
  web3: Web3,
}