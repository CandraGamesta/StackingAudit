import React from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import { ButtonBase, Typography } from "@mui/material";
import Button from "@mui/material/Button";
import { useAuth, useContract } from "../hooks/web3Auth";
import CurrencyIcon from "src/assets/blackmarket/Currency-icon.png";
import StakingCoin from "src/assets/blackmarket/StakingCoin.png";
import Avatar from "@mui/material/Avatar";
import APR from "./APR";
import CalculationIcon from "src/assets/blackmarket/CalculationIcon";
import Divider from "@mui/material/Divider";
import StakingHeader from "./staking-header";
import StakingContract from "../../contractData/stakingAbi";
import DrugzContract from "../../contractData/DrugzAbi";
import BigNumber from "bignumber.js";
import StakingButtons from "../buttons/stakingButtons";
import StakingDepositDialogue from "../dialogues/stakingDepositDialogue";
import StakingWithdrawDialogue from "../dialogues/stakingWithdrawDialogue";
import { toWei } from "web3-utils";
import axios from "axios";
import Skeleton from "@mui/material/Skeleton";
import Alert from "@mui/material/Alert";
export default function Staking() {
  const [open, setOpen] = React.useState(false);
  const [isApproved, setIsApproved] = React.useState(false);
  const [loaded, setLoaded] = React.useState(false);
  const [totalStaked, setTotalStaked] = React.useState(0);
  const [stakedAmount, setStakedAmount] = React.useState(0);
  const [pendingReward, setPendingReward] = React.useState(0);
  const [amount, setAmount] = React.useState(0);
  const [Apr, setApr] = React.useState({
    d365: {
      return: 0,
      percent: -1,
    },
    d1: {
      return: 0,
      percent: 0,
    },
    d7: {
      return: 0,
      percent: 0,
    },
    d30: {
      return: 0,
      percent: 0,
    },
  });
  const [openStake, setOpenStake] = React.useState(false);
  const [openWithdraw, setOpenWithdraw] = React.useState(false);
  const [price, setPrice] = React.useState(0);
  const handleAmountChange = (event: any) => {
    if (event.target.value < 0) {
      setAmount(0);
    } else {
      setAmount(event.target.value);
    }
  };
  const handleCloseStake = () => {
    setOpenStake(false);
  };
  const handleCloseStakeWithdraw = () => {
    setOpenWithdraw(false);
  };

  const { account, chainId } = useAuth();
  const { contract: stakingContract, methods: stakingMethods } = useContract(
    StakingContract.abi,
    StakingContract.address
  );
  const { contract: drugzContract, methods: drugzMethods } = useContract(
    DrugzContract.abi,
    DrugzContract.address
  );

  const approve = async () => {
    drugzMethods
      .approve(
        StakingContract.address,
        toWei(`${new BigNumber(999999999).toFixed(18, 1)}`)
      )
      .send({
        from: account,
        gasPrice: parseInt(`${new BigNumber(10).pow(10)}`),
      })
      .on("transactionHash", (tx: string) => {
        console.log("hash", tx);
      })
      .on("receipt", (rc: any) => {
        console.log("receipt", rc);
        setIsApproved(true);
      })
      .on("error", (error: any, receipt: any) => {
        console.log("error", error, receipt);
      });
  };
  const harvest = async () => {
    await stakingMethods
      .harvest()
      .send({
        from: account,
        gasPrice: parseInt(`${new BigNumber(10).pow(10)}`),
      })
      .on("transactionHash", (tx: string) => {
        console.log("hash", tx);
      })
      .on("receipt", (rc: any) => {
        console.log("receipt", rc);
        fetchData();
      })
      .on("error", (error: any, receipt: any) => {
        console.log("error", error, receipt);
      });
  };
  const compound = async () => {
    await stakingMethods
      .compound()
      .send({
        from: account,
        gasPrice: parseInt(`${new BigNumber(10).pow(10)}`),
      })
      .on("transactionHash", (tx: string) => {
        console.log("hash", tx);
      })
      .on("receipt", (rc: any) => {
        console.log("receipt", rc);
        fetchData();
      })
      .on("error", (error: any, receipt: any) => {
        console.log("error", error, receipt);
      });
  };
  const deposit = async () => {
    setOpenStake(false);
    await stakingMethods
      .enterStaking(toWei(`${new BigNumber(amount).toFixed(18, 1)}`))
      .send({
        from: account,
        gasPrice: parseInt(`${new BigNumber(10).pow(10)}`),
      })
      .on("transactionHash", (tx: string) => {
        console.log("hash", tx);
      })
      .on("receipt", (rc: any) => {
        console.log("receipt", rc);
        fetchData();
      })
      .on("error", (error: any, receipt: any) => {
        console.log("error", error, receipt);
      });
  };
  const withdraw = async () => {
    setOpenWithdraw(false);
    await stakingMethods
      .leaveStaking(toWei(`${new BigNumber(amount).toFixed(18, 1)}`))
      .send({
        from: account,
        gasPrice: parseInt(`${new BigNumber(10).pow(10)}`),
      })
      .on("transactionHash", (tx: string) => {
        console.log("hash", tx);
      })
      .on("receipt", (rc: any) => {
        console.log("receipt", rc);
        fetchData();
      })
      .on("error", (error: any, receipt: any) => {
        console.log("error", error, receipt);
      });
  };

  const fetchData = async () => {
    stakingMethods
      ?.stakings(account)
      .call({ from: account })
      .then(function (result: any) {
        console.log("staked amount");
        setStakedAmount(
          parseFloat((result.stakedAmount / 10 ** 18).toFixed(7))
        );
      });
    stakingMethods
      ?.pendingReward(account)
      .call({ from: account })
      .then(function (result: any) {
        console.log("pending reward");
        setPendingReward(parseFloat((result / 10 ** 18).toFixed(7)));
      });
    stakingMethods
      ?.totalStaked()
      .call({ from: account })
      .then(function (result: any) {
        console.log("total staked");
        setTotalStaked(parseFloat((result / 10 ** 18).toFixed(7)));
      });
    drugzMethods
      ?.allowance(account, StakingContract.address)
      .call({ from: account })
      .then(function (result: any) {
        setLoaded(true);
        console.log("allowance");
        console.log(result);
        if (parseInt(result) > 0) {
          setIsApproved(true);
          console.log("inside set approved");
        }
      });
  };

  React.useEffect(() => {
    fetchData();
  }, [stakingMethods, drugzMethods]);
  const MINUTE_MS = 20000;

  const calculateAPR = async () => {
    const initialStake = new BigNumber(1000)
      .div(price)
      .times(new BigNumber(10).pow(18))
      .toNumber();
    const emission = await stakingMethods.tokenPerBlock().call();

    //for 30 percent
    //const emission = 600000000000000000;
    const totalStaked = await stakingMethods.totalStaked().call();

    const compoundEmitted = new BigNumber(emission).toNumber();
    const totalPool =
      new BigNumber(totalStaked).toNumber() ||
      new BigNumber(1000000).times(new BigNumber(10).pow(18)).toNumber();
    let d1 = 0;
    let d7 = 0;
    let d30 = 0;
    const max = new BigNumber(288).times(365); // 288 compounds per day for 365 days (compound after 5 seconds)
    const maxNumber = max.toNumber();
    let previousReward = 0;
    for (let j = 1; j <= maxNumber; j++) {
      const EmitBlockTotal =
        compoundEmitted / (totalPool + compoundEmitted * (j - 1) * 60);
      const reward = (initialStake + previousReward) * EmitBlockTotal * 60;
      previousReward += reward;
      if (j == 1 * 288 && !d1) d1 = previousReward;
      if (j == 8 * 288 && !d7) d7 = previousReward;
      if (j == 30 * 288 && !d30) d30 = previousReward;
    }
    const readableD1 = new BigNumber(d1)
      .div(new BigNumber(10).pow(18))
      .toNumber();
    const readableD7 = new BigNumber(d7)
      .div(new BigNumber(10).pow(18))
      .toNumber();
    const readableD30 = new BigNumber(d30)
      .div(new BigNumber(10).pow(18))
      .toNumber();
    const readableD365 = new BigNumber(previousReward)
      .div(new BigNumber(10).pow(18))
      .toNumber();
    let previousCalc = {
      constants: {
        initialStake,
        totalPool: totalPool,
        price: price,
        crushPerBlock: new BigNumber(emission)
          .div(new BigNumber(10).pow(18))
          .toFixed(),
      },
      d1: {
        return: parseFloat(readableD1.toFixed(4)),
        percent: parseFloat(((d1 / initialStake) * 100).toFixed(4)),
      },
      d7: {
        return: parseFloat(readableD7.toFixed(4)),
        percent: parseFloat(((d7 / initialStake) * 100).toFixed(4)),
      },
      d30: {
        return: parseFloat(readableD30.toFixed(4)),
        percent: parseFloat(((d30 / initialStake) * 100).toFixed(4)),
      },
      d365: {
        return: parseFloat(readableD365.toFixed(4)),
        percent: parseFloat(((previousReward / initialStake) * 100).toFixed(4)),
      },
    };
    console.log(previousCalc);
    setApr(previousCalc);
    /* //new calculation didnt work
    const BlocksPerYear = 105112000;
    let yearlyTokenRewardAllocation = BlocksPerYear * emission;
    let tokenRewardAPR = new BigNumber(yearlyTokenRewardAllocation).times(price).div(new BigNumber(totalPool).times(price)).times(100);
    console.log(tokenRewardAPR.toNumber()); */
  };

  React.useEffect(() => {
    //https://api.pancakeswap.info/api/v2/tokens/0x27e2A0E643c7f17959F84C345d2123B77bbd412c
    let url: string;
    url =
      "https://api.pancakeswap.info/api/v2/tokens/0x27e2A0E643c7f17959F84C345d2123B77bbd412c";

    axios
      .get(url)
      .then(function (response: any) {
        console.log(response);
        setPrice(response.data.data.price);
        //calculateAPR();
      })
      .catch(function (error) {
        console.log(error);
      });
  });
  React.useEffect(() => {
    const interval = setInterval(() => {
      console.log("Logs every minute");
      fetchData();
      calculateAPR();
    }, MINUTE_MS);
    return () => clearInterval(interval); // This represents the unmount function, in which you need to clear your interval to prevent memory leaks.
  }, [fetchData]);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  return (
    <Paper
      sx={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "transparent",
        mb: 4,
      }}
    >
      <StakingHeader />
      {chainId !== 97 ? (
        <Alert
          severity="info"
          sx={{
            color: "white",
            fontFamily: "ThaleahFat",
            fontSize: "26px",
            border: `3px solid #0b0c14`,
            borderRadius: 3,
            backgroundColor: "#040508",
            marginTop: "auto",
            marginBottom: "auto",
            "& .MuiAlert-icon": {
              marginTop: "auto",
              marginBottom: "auto",
              padding: "none",
            },
          }}
        >
          Please switch your network to Binance Smart Chain!
        </Alert>
      ) : (
        <></>
      )}

      <Typography
        sx={{
          fontFamily: "ThaleahFat",
          fontSize: "40px",
          pt: 2,
        }}
      >
        Staking Pool
      </Typography>
      <Typography
        sx={{
          fontFamily: "ThaleahFat",
          fontSize: "30px",
          pb: 2,
        }}
      >
        DRUGZ Staking Pool
      </Typography>
      <Box
        sx={{
          display: "flex",
          flexWrap: "wrap",
          "& > :not(style)": {
            width: 350,
            minWidth: 350,
            height: "auto",
            backgroundColor: "#11131a",
            borderRadius: "20px",
            pb: 3,
          },
        }}
      >
        <Paper elevation={24}>
          <Grid
            container
            sx={{
              width: "100%",
              color: "white",
              textAlign: "left",
              pl: 5,
              pr: 5,
              pt: 3,
            }}
          >
            <Grid item md={6} sm={6} xs={6} sx={{ height: "80px" }}>
              <Typography
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "30px",
                  color: "#8600d4",
                  textAlign: "left",
                }}
              >
                Stake coin
              </Typography>
              <Typography
                sx={{
                  fontSize: "10px",
                  textAlign: "left",
                  lineHeight: 0,
                }}
              >
                Stake, Earn - And more!
              </Typography>
            </Grid>
            <Grid item md={3} sm={3} xs={3} sx={{ height: "80px" }}></Grid>
            <Grid item md={3} sm={3} xs={3} sx={{ height: "80px" }}>
              <Avatar
                variant="square"
                alt="test avatar"
                src={StakingCoin}
                sx={{ height: "70px", width: "70px" }}
              />
            </Grid>

            <Grid item md={12} sm={12} xs={12}>
              <Divider sx={{ borderColor: "#303442" }} />
            </Grid>
            <Grid item md={12} sm={12} xs={12}>
              <Typography
                sx={{
                  fontSize: "16px",
                  color: "#97a4b0",
                  textAlign: "center",
                  my: 1,
                }}
              >
                Manual Compounding Pool
              </Typography>
              <Divider sx={{ borderColor: "#303442" }} />
            </Grid>
            <Grid item md={6} sm={6} xs={6}>
              <Typography
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "22px",
                  color: "#97a4b0",
                }}
              >
                APR
              </Typography>
            </Grid>
            <Grid
              item
              md={6}
              sm={6}
              xs={6}
              container
              direction="row"
              sx={{
                justifyContent: "right",
                textAlign: "right",
              }}
            >
              <Grid item>
                <ButtonBase onClick={handleClickOpen} sx={{ pr: 1, pt: 1 }}>
                  <CalculationIcon sx={{ height: "16px", width: "16px" }} />
                </ButtonBase>
              </Grid>
              <Grid item>
                {Apr.d365.percent > -1 ? (
                  <Typography
                    sx={{
                      fontFamily: "ThaleahFat",
                      fontSize: "22px",
                      textAlign: "right",
                    }}
                  >
                    {Apr.d365.percent}%
                  </Typography>
                ) : (
                  <Skeleton variant="text" width={40} height={40} />
                )}
                {/* <Typography
                  sx={{
                    fontFamily: "ThaleahFat",
                    fontSize: "22px",
                    textAlign: "right",
                  }}
                >
                {Apr.d365.percent}% 
                </Typography>*/}
              </Grid>
            </Grid>

            <Grid item md={6} sm={6} xs={6}>
              <Typography
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "22px",
                  color: "#97a4b0",
                }}
              >
                Earn
              </Typography>
            </Grid>
            <Grid item md={6} sm={6} xs={6}>
              <Typography
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "22px",
                  textAlign: "right",
                }}
              >
                DRUGZ
              </Typography>
            </Grid>

            <Grid item md={6} sm={6} xs={6}>
              <Typography
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "22px",
                  color: "#97a4b0",
                }}
              >
                Staked
              </Typography>
            </Grid>
            <Grid
              item
              md={6}
              sm={6}
              xs={6}
              sx={{
                justifyContent: "right",
                textAlign: "right",
              }}
              container
              direction="row"
            >
              <Grid item>
                <Avatar
                  variant="square"
                  alt="test avatar"
                  src={CurrencyIcon}
                  sx={{ height: "16px", width: "16px", mt: 1, mr: 1 }}
                />
              </Grid>
              <Grid item>
                <Typography
                  sx={{
                    fontFamily: "ThaleahFat",
                    fontSize: "22px",
                    textAlign: "right",
                  }}
                >
                  {stakedAmount}
                </Typography>
              </Grid>
            </Grid>

            <Grid item md={6} sm={6} xs={6}>
              <Typography
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "22px",
                  color: "#97a4b0",
                }}
              >
                DRUGZ Earned
              </Typography>
            </Grid>
            <Grid
              item
              md={6}
              sm={6}
              xs={6}
              sx={{
                justifyContent: "right",
                textAlign: "right",
              }}
              container
              direction="row"
            >
              <Grid item>
                <Avatar
                  variant="square"
                  alt="test avatar"
                  src={CurrencyIcon}
                  sx={{ height: "16px", width: "16px", mt: 1, mr: 1 }}
                />
              </Grid>
              <Grid item>
                <Typography
                  sx={{
                    fontFamily: "ThaleahFat",
                    fontSize: "22px",
                    textAlign: "right",
                  }}
                >
                  {pendingReward}
                </Typography>
              </Grid>
            </Grid>
            <StakingButtons
              loaded={loaded}
              isApproved={isApproved}
              harvest={harvest}
              compound={compound}
              approve={approve}
              stakedAmount={stakedAmount}
              deposit={setOpenStake}
              withdraw={setOpenWithdraw}
            />

            <Grid item md={6} sm={6} xs={6}>
              <Typography
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "16px",
                  color: "#97a4b0",
                }}
              >
                Total staked
              </Typography>
            </Grid>
            <Grid item md={6} sm={6} xs={6}>
              <Typography
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "16px",
                  textAlign: "right",
                }}
              >
                {totalStaked} Drugz
              </Typography>
            </Grid>
            <Grid item md={6} sm={6} xs={6}>
              <Typography
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "16px",
                  color: "#97a4b0",
                }}
              >
                Early Withdrawal Fee
              </Typography>
            </Grid>
            <Grid item md={6} sm={6} xs={6}>
              <Typography
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "16px",
                  textAlign: "right",
                }}
              >
                0.5%
              </Typography>
            </Grid>
            <Grid item md={6} sm={6} xs={6}>
              <Typography
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "16px",
                  color: "#97a4b0",
                }}
              >
                Early Withdrawal Time
              </Typography>
            </Grid>
            <Grid item md={6} sm={6} xs={6}>
              <Typography
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "16px",
                  textAlign: "right",
                }}
              >
                72 Hours
              </Typography>
            </Grid>
          </Grid>
        </Paper>
      </Box>
      <APR open={open} handleClose={handleClose} Apr={Apr}></APR>
      <StakingDepositDialogue
        action={deposit}
        amount={amount}
        openStake={openStake}
        handleCloseStake={handleCloseStake}
        handleAmountChange={handleAmountChange}
      />
      <StakingWithdrawDialogue
        action={withdraw}
        amount={amount}
        openStake={openWithdraw}
        handleCloseStake={handleCloseStakeWithdraw}
        handleAmountChange={handleAmountChange}
      />
    </Paper>
  );
}
