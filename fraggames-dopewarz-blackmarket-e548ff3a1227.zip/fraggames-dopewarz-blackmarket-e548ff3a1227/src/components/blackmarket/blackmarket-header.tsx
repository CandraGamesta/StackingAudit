import * as React from "react";
import { Link } from "react-router-dom";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import ButtonBase from "@mui/material/ButtonBase";
import Button from "@mui/material/Button";
import MenuItem from "@mui/material/MenuItem";
import Logo from "../../assets/blackmarket/logo.png";
import { useHistory, useLocation } from "react-router-dom";
import { useAuth } from "../hooks/web3Auth";
import DynamicMenu from "../userMenus/dynamicMenu";
import { useEagerConnect } from "../hooks/web3Auth";
import NavButton from "../buttons/navButton";
import DashboardSelected from "src/assets/blackmarket/Dashboard-selected.png";
import DashboardUnselected from "src/assets/blackmarket/Dashboard-unselected.png";
import MarketplaceSelected from "src/assets/blackmarket/Marketplace-selected.png";
import MarketplaceUnselected from "src/assets/blackmarket/Marketplace-Unselected.png";
import StakingSelected from "src/assets/blackmarket/Staking_Selected_icon.png";
import StakingUnselected from "src/assets/blackmarket/Staking_Unselected_icon.png";

const pages = [
  {
    name: "Dashboard",
    route: "/blackmarket",
    iconSelected: DashboardSelected,
    iconUnselected: DashboardUnselected,
  },
  {
    name: "Marketplace",
    route: "/blackmarket",
    iconSelected: MarketplaceSelected,
    iconUnselected: MarketplaceUnselected,
  },
  {
    name: "Staking",
    route: "/blackmarket/staking",
    iconSelected: StakingSelected,
    iconUnselected: StakingUnselected,
  },
];

export default function BlackmarketHeader() {
  let history = useHistory();
  let location = useLocation();
  console.log(location.pathname);

  const [anchorElNav, setAnchorElNav] = React.useState<null | HTMLElement>(
    null
  );
  const [anchorElUser, setAnchorElUser] = React.useState<null | HTMLElement>(
    null
  );

  const handleOpenNavMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorElNav(event.currentTarget);
  };
  const handleOpenUserMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };
  const handleNavMenuClick = (key: string) => {
    console.log(key);
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };
  const handleNavClick = (route: any) => {
    console.log("inside nav click");
    history.push("/" + route.route);
  };
  const logoH = "130px";
  const logoW = "25px";

  useEagerConnect();
  const { login, logout, account, chainId } = useAuth();
  const settings = [
    {
      name: "Profile",
      route: "/user/" + account,
    },
    {
      name: "Account History",
      route: "/accounthistory",
    },
    {
      name: "Payouts",
      route: "/payoutsstatus",
    },
  ];
  return (
    <AppBar
      position="sticky"
      sx={{ backgroundColor: "#000000", pl: 2, height: "55px", minHeight: "55px !important" }}
    >
      <Toolbar disableGutters sx={{ minHeight: "55px !important" }}>
        {/* <Typography
                        variant="h4"
                        noWrap
                        component="div"
                        sx={{ mr: 2, display: { xs: 'none', md: 'flex' } }}
                    >
                        LOGO
                    </Typography> */}
        <Link to="/">
          <ButtonBase sx={{ mr: 2, display: { xs: "none", md: "flex" } }}>
            <img
              src={Logo}
              width="130px"
              height="25px"
              alt="DopeWarz Logo Header"
            />
          </ButtonBase>
        </Link>
        <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}>
          <IconButton
            size="large"
            aria-label="account of current user"
            aria-controls="menu-appbar"
            aria-haspopup="true"
            onClick={handleOpenNavMenu}
            sx={{ color: "white" }}
          >
            <MenuIcon />
          </IconButton>
          <Menu
            id="menu-appbar"
            anchorEl={anchorElNav}
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left",
            }}
            keepMounted
            transformOrigin={{
              vertical: "top",
              horizontal: "left",
            }}
            open={Boolean(anchorElNav)}
            onClose={handleCloseNavMenu}
            sx={{
              display: { xs: "block", md: "none" },
              color: "white",
              "& .MuiPaper-root": {
                backgroundColor: "#242735",
              },
            }}
          >
            {/* <MenuItem key={pages[0]} onClick={handleNavClick} sx={{ color: "#8600d4" }}>
                {pages[0]}
              </MenuItem> */}
            {pages.map((page, index) => (
              <MenuItem
                key={index}
                onClick={handleCloseNavMenu}
                sx={{ color: "#8600d4" }}
              >
                <Button href={page.route}> {page.name} </Button>
              </MenuItem>
            ))}
          </Menu>
        </Box>
        <Link to="/">
          <ButtonBase
            component="div"
            style={{ justifyContent: "flex-start" }}
            sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}
          >
            <img
              src={Logo}
              width="105px"
              height="25px"
              alt="DopeWarz Logo Header"
            />
          </ButtonBase>
        </Link>
        <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}>
          {pages.map((page, index) => (
            <NavButton currentPage={page} location={location} key={index} />
          ))}
        </Box>

        
          <DynamicMenu settings={settings} />
        
      </Toolbar>
    </AppBar>
  );
}
