import React from "react";
import { useEffect } from "react";
import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import { Typography } from "@mui/material";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import ComingSoon from "./ComingSoon";
import Avatar from "@mui/material/Avatar";
import DopezIcon from "../../assets/blackmarket/Dopez-icon.png";
import DOZIcon from "../../assets/blackmarket/DOZ-icon.png";
import LootboxIcon from "../../assets/blackmarket/LootboxIcon.png";
import BlockZIcon from "../../assets/blackmarket/BlockZ-icon.png";
import { useAuth } from "src/components/hooks/web3Auth";
import { useLocation } from "react-router-dom";
import MarketplaceContent from "./marketplaceContent";
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

export default function Profile() {
  const { login, account } = useAuth();
  const [value, setValue] = React.useState(1);
  let location : any = useLocation();
  const [type, setType] = React.useState(location.state?.type);
  const [curAccount, setCurAccount] = React.useState<any>();
  useEffect(() => {
    let currentAccountArr = location.pathname.split("/");
    let currentAccount = currentAccountArr[currentAccountArr.length - 1];
    console.log("current account is:" + currentAccount);
    setCurAccount(currentAccount);
  }, [location]);

  useEffect(()=>{
    if(type === "Blockz"){
      setValue(1);
    }else if(type === "Dopez"){
      setValue(2);
    }else if(type === "Doz"){
      setValue(3);
    }
  },[type])
  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    console.log(event);
    setValue(newValue);
  };
  var sectionStyle = {
    marginTop: 0,
    color: "primary",
  };
  var boxStyle = {
    width: "90%",
    alignItems: "center",
    justifyContent: "center",
    margin: "auto",
    border: `3px solid #0b0c14`,
    borderRadius: 3,
    backgroundColor: "#040508",
    color: "white",
    padding: 10,
  };
  return (
    <React.Fragment>
      <CssBaseline />
      <div style={sectionStyle} className="pageMaxSize">
        <Box
          sx={{
            display: "flex",
            width: "100%",
            height: "100%",
          }}
        >
          <Paper
            sx={{
              backgroundColor: "transparent",
              position: "relative",
              pt: 4,
              pb: 3,
              width: "100%",
            }}
          >
            <Box sx={{ flexGrow: 1, margin: "5px", marginBottom: "50px" }}>
              <Grid
                container
                alignItems="center"
                justifyContent="center"
                sx={{
                  display: "flex",
                  width: "100%",
                  border: (theme) => `2px solid ${theme.palette.divider}`,
                  borderRadius: 3,
                }}
              >
                <Grid item md={4}>
                  <Box style={boxStyle}>
                    <Typography>User Wallet</Typography>
                    <Typography
                      sx={{
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        fontSize: "15px",
                      }}
                    >
                      {curAccount}
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </Box>
            <Tabs
              value={value}
              onChange={handleChange}
              color="secondary"
              indicatorColor="primary"
              variant="fullWidth"
              sx={{
                color: "white",
                "& .MuiTabs-indicator": {
                  backgroundColor: "#8600d4",
                  color: "#ffff",
                },
                "& .MuiTabs": {
                  color: "#ffff",
                },
              }}
            >
              <Tab
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "24px",
                }}
                value={2}
                label="Dopez"
                icon={
                  <Avatar
                    variant="square"
                    alt="test avatar"
                    src={DopezIcon}
                    sx={{ height: "24px", width: "24px" }}
                  />
                }
                iconPosition="start"
                {...a11yProps(1)}
              />
              <Tab
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "24px",
                }}
                value={1}
                label="BlockZ"
                icon={
                  <Avatar
                    variant="square"
                    alt="test avatar"
                    src={BlockZIcon}
                    sx={{ height: "24px", width: "24px" }}
                  />
                }
                iconPosition="start"
                {...a11yProps(0)}
              />
              <Tab
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "24px",
                }}
                value={3}
                label="DOZ"
                icon={
                  <Avatar
                    variant="square"
                    alt="test avatar"
                    src={DOZIcon}
                    sx={{ height: "24px", width: "24px" }}
                  />
                }
                iconPosition="start"
                {...a11yProps(2)}
              />
              <Tab
                sx={{
                  fontFamily: "ThaleahFat",
                  fontSize: "24px",
                }}
                value={4}
                label="Lootboxes"
                icon={
                  <Avatar
                    variant="square"
                    alt="test avatar"
                    src={LootboxIcon}
                    sx={{ height: "24px", width: "24px" }}
                  />
                }
                iconPosition="start"
                {...a11yProps(3)}
              />
            </Tabs>
            <TabPanel value={value} index={2}>
              <MarketplaceContent
                type="Dopez"
                path="profile"
                account={curAccount}
              />
            </TabPanel>
            <TabPanel value={value} index={1}>
              <MarketplaceContent
                type="Blockz"
                path="profile"
                account={curAccount}
              />
            </TabPanel>
            <TabPanel value={value} index={3}>
              <MarketplaceContent
                type="Doz"
                path="profile"
                account={curAccount}
              />
            </TabPanel>
            <TabPanel value={value} index={4}>
              <ComingSoon />
            </TabPanel>
          </Paper>
        </Box>
      </div>
    </React.Fragment>
  );
}
