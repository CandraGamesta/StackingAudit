import * as React from "react";
import Grid from "@mui/material/Grid";
import Avatar from "@mui/material/Avatar";
import { Typography } from "@mui/material";
import { useAuth, useContract } from "../hooks/web3Auth";
import BlackmarketContract from "../../contractData/blackmarektabi";
import CurrencyIcon from "src/assets/blackmarket/Currency-icon.png";
import Button from "@mui/material/Button";
import BigNumber from "bignumber.js";

export default function BuyAndSell(props: any) {
  const { account } = useAuth();
  const { contract: nftContract, methods: nftMethods } = useContract(
    BlackmarketContract.abi,
    BlackmarketContract.address
  );
  const onEditListing = async (action: any) => {
    props.setBackdrop(true);
    let isApproved = await nftMethods
      .isApprovedForAll(account, "0x0E5De84bFC1A9799a0FdA4eF0Bd13b6A20e97d89")
      .call();
    console.log("is approved:" + isApproved);
    if (
      !isApproved &&
      account !== "0x0E5De84bFC1A9799a0FdA4eF0Bd13b6A20e97d89"
    ) {
      nftMethods
        .setApprovalForAll("0x0E5De84bFC1A9799a0FdA4eF0Bd13b6A20e97d89", true)
        .send({
          from: account,
          gasPrice: parseInt(`${new BigNumber(10).pow(10)}`),
        })
        .on("transactionHash", (tx: string) => {
          console.log("hash", tx);
        })
        .on("receipt", (rc: any) => {
          console.log("receipt", rc);
          action(true);
        })
        .on("error", (error: any, receipt: any) => {
          console.log("error", error, receipt);
          props.setBackdrop(false);
        });
    } else {
      action(true);
    }
  };
  console.log(props.cards.status);
  if (account) {
    console.log(account);
    if (
      props.cards.ownerAddress === account ||
      props.ownerAddress === account
    ) {
      console.log(props.cards.ownerAddress);
      console.log(props.ownerAddress);
      console.log("ownerAddress matched");
      if (props.cards.status === "listed") {
        return (
          <>
            <Button
              variant="outlined"
              color="success"
              onClick={() => {
                onEditListing(props.editListing);
              }}
            >
              Edit Listing
            </Button>
            <Button
              variant="outlined"
              color="success"
              onClick={props.cancelListing}
              sx={{ml:2}}
            >
              Cancel Listing
            </Button>
          </>
        );
      } else {
        return (
          <Button
            variant="outlined"
            color="success"
            onClick={() => {
              onEditListing(props.listForSale);
            }}
          >
            List For Sale
          </Button>
        );
      }
    } else {
      console.log(props.cards.status);
      if (props.cards.status === "listed") {
        console.log("ownerAddress not matched");
        return (
          <>
            <Grid
              item
              md={6}
              textAlign="right"
              container
              direction="row"
              alignItems="right"
              justifyContent="right"
            >
              <Grid item pr={1} pt={1}>
                <Avatar
                  variant="square"
                  alt="test avatar"
                  src={CurrencyIcon}
                  sx={{ height: "16px", width: "16px" }}
                />
              </Grid>
              <Grid item>
                <Typography sx={{ pr: 1, pt: 0.5 }}>
                  {props.cards.price} Drugz
                </Typography>
              </Grid>
            </Grid>
            <Grid item md={6}>
              <Button
                variant="contained"
                color="secondary"
                sx={{
                  lineHeight: 1.4,
                  letterSpacing: 1,
                  fontFamily: "ThaleahFat",
                  fontSize: 24,
                  p: 0,
                  px: 4,
                  color: "black",
                  borderRadius: 0,
                }}
                onClick={props.buyNFT}
              >
                Buy
              </Button>
            </Grid>
          </>
        );
      } else {
        return <Typography>Not Currently Listed</Typography>;
      }
    }
  } else {
    console.log(props.cards.status);
    if (props.cards.status === "listed") {
      console.log("ownerAddress not matched");
      return (
        <>
          <Grid
            item
            md={6}
            textAlign="right"
            container
            direction="row"
            alignItems="right"
            justifyContent="right"
          >
            <Grid item pr={1} pt={1}>
              <Avatar
                variant="square"
                alt="test avatar"
                src={CurrencyIcon}
                sx={{ height: "16px", width: "16px" }}
              />
            </Grid>
            <Grid item>
              <Typography sx={{ pr: 1, pt: 0.5 }}>
                {props.cards.price} Drugz
              </Typography>
            </Grid>
          </Grid>
          <Grid item md={6}>
            <Button
              variant="contained"
              color="secondary"
              sx={{
                lineHeight: 1.4,
                letterSpacing: 1,
                fontFamily: "ThaleahFat",
                fontSize: 24,
                p: 0,
                px: 4,
                color: "black",
                borderRadius: 0,
              }}
              onClick={props.buyNFT}
            >
              Buy
            </Button>
          </Grid>
        </>
      );
    } else {
      return <Typography>Not Currently Listed</Typography>;
    }
  }
}
