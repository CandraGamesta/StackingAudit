import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import PaginationItem from "@mui/material/PaginationItem";
import Grid from "@mui/material/Grid";
import ClaimCard, { ClaimCardProps } from "src/components/card/ClaimCard";
import { useState, useMemo } from "react";
export default function MarketplaceCards(props: any) {
  const placeholderCardData: ClaimCardProps = {
    title: "Dopez",
    number: 100,
    price: 100,
    action: () => console.log("pool action"),
    actionName: "Button",
  };
  const [cards, setCards] = useState<Array<ClaimCardProps>>(
    new Array(25).fill(1).map((v, i) => ({
      ...placeholderCardData,
      title: placeholderCardData.title + " " + i,
    }))
  );
  const [page, setPage] = useState<number>(1);
  const [balanceAmount, setBalanceAmount] = useState<number>(123456789);

  const pageSize = 6;
  const totalPages = useMemo(() => {
    return Math.ceil(cards.length / pageSize);
  }, [cards, pageSize]);

  const cardsToShow = useMemo(() => {
    const startIndex = (page - 1) * pageSize;
    const endIndex = page * pageSize;
    return cards.slice(startIndex, endIndex);
  }, [cards, page, pageSize]);
  const handlePageChange = (event: any, value: any) => {
    setPage(value);
  };

  return (
    <Grid container justifyContent="center" spacing={4} alignItems="center">
      {cardsToShow.map((card, cardIdx) => (
        <Grid item key={`pool-card-${cardIdx}`}>
          <ClaimCard {...card} />
        </Grid>
      ))}
      <Grid item xs={12} />
      <Stack spacing={2}>
        <Pagination
          count={totalPages}
          page={page}
          onChange={handlePageChange}
          renderItem={(item) => (
            <PaginationItem sx={{ color: "whitesmoke" }} {...item} />
          )}
        />
      </Stack>
    </Grid>
  );
}
