import * as React from "react";
import { useState, useEffect } from "react";
import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import Chip from "@mui/material/Chip";
import { Typography } from "@mui/material";
import { useHistory } from "react-router-dom";
import { useAuth } from "../hooks/web3Auth";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { useLocation } from "react-router-dom";
import SalesHistory from "./SalesHistory";
import Snackbar from "@mui/material/Snackbar";
import Web3 from "web3";
import axios from "axios";
import BuyAndSell from "./BuyAndSell";
import OrderSuccess from "../dialogues/order-success";
import EditListing from "../dialogues/editListing";
import BlockzInfo from "./BlockzInfo";
import DopezInfo from "./DopezInfo";
import Backdrop from "@mui/material/Backdrop";
import NftImg from "./NftImg";
import CircularProgress from "@mui/material/CircularProgress";
import DynamicInfo from "./DynamicInfo";
import { useIsPreLaunchEnabled } from "../hooks/preLaunch";
import Alert from "@mui/material/Alert";
export default function BlockzDetail() {
  const preLaunchEnabled: boolean = useIsPreLaunchEnabled();
  const location: any = useLocation();
  const [cards, setCards] = useState(location.state.card);
  const [type, setType] = useState(location.state.type);
  const [buySuccess, setBuySuccess] = React.useState(false);
  const [backdrop, setBackdrop] = React.useState(false);
  const { account } = useAuth();
  const web3 = new Web3(Web3.givenProvider);
  let history = useHistory();
  var sectionStyle = {
    marginTop: 0,
  };

  const [SnackbarOpen, setSnackbarOpen] = React.useState(false);

  const handleSnackbarClose = (
    event: React.SyntheticEvent | Event,
    reason?: string
  ) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };
  console.log("blockz detail");
  console.log(location.state);
  const [open, setOpen] = useState(false);

  const [openListForSale, setOpenListForSale] = useState(false);
  const [listingPrice, setListingPrice] = useState(0);
  const [openEditListing, setOpenEditListing] = useState(false);
  const [transactionHistory, setTransactionHistory] = useState([]);

  const [bnbPrice, setBnbPrice] = useState(1);

  const handlePriceChange = (event: any) => {
    setListingPrice(event.target.value);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const handleCloseListForSale = () => {
    setOpenListForSale(false);
  };

  const handleCloseEditListing = () => {
    setOpenEditListing(false);
  };

  function handleClick() {
    history.push({
      pathname: "/",
      state: { type: type },
    });
  }
  useEffect(() => {
    axios
      .get("https://api.binance.com/api/v3/ticker/price?symbol=BNBUSDC")
      .then(function (response: any) {
        console.log(response);
        setBnbPrice(response.data.price);
      })
      .catch(function (error) {
        console.log(error);
      });

    let url = "https://dopewarz.frag-games.com/api/transactions/nft";
    let payload = {
      tokenId: cards.nft._id,
    };
    axios
      .post(url, payload)
      .then(function (response: any) {
        console.log(response);
        setTransactionHistory(response.data.transactions);
      })
      .catch(function (error) {
        console.log(error);
      });
  }, []);
  const buyNft = () => {
    if (account) {
      console.log("in buy nft price is:" + bnbPrice);
      setBackdrop(true);
      let priceInBnb = cards.price / bnbPrice;
      let weiPrice = web3.utils.toWei(priceInBnb.toFixed(10).toString());
      web3.eth
        .sendTransaction({
          to: "0x0E5De84bFC1A9799a0FdA4eF0Bd13b6A20e97d89",
          value: weiPrice.toString(),
          from: account?.toString(),
        })
        .then(function (receipt: any) {
          console.log(receipt);
          let url = "https://dopewarz.frag-games.com/api/nfts/buy-nft";
          let payload = {
            tokenId: cards.nft._id,
            wallet: account,
          };
          axios
            .post(url, payload)
            .then(function (response: any) {
              console.log(response);
              setBackdrop(false);
              setBuySuccess(true);
            })
            .catch(function (error) {
              console.log(error);
              setBackdrop(false);
            });
        })
        .finally(() => {
          setBackdrop(false);
        });
    } else {
      return (
        <Snackbar
          open={SnackbarOpen}
          autoHideDuration={6000}
          onClose={handleSnackbarClose}
          message="Please connect your Wallet first"
        />
      );
    }
  };
  const listForSale = () => {
    let acc = account ? account : "";
    axios
      .get("https://dopewarz.frag-games.com/api/signedData")
      .then(function (response: any) {
        web3.eth.personal
          .sign(web3.utils.toHex(response.data.signedData.data), acc, "")
          .then(function (receipt: any) {
            console.log(receipt);
            let url =
              "https://dopewarz.frag-games.com/api/listForSale/create-listing";
            let payload = {
              tokenId: cards.nft._id,
              wallet: account,
              price: listingPrice,
              signature: receipt,
              signingDataId: response.data.signedData._id,
            };
            axios
              .post(url, payload)
              .then(function (response: any) {
                console.log(response);
                handleCloseListForSale();
                setBackdrop(false);
                history.push("/blackmarket");
              })
              .catch(function (error) {
                console.log(error);
                setBackdrop(false);
              });
          })
          .finally(() => {
            setBackdrop(false);
          });
      })
      .catch(function (error) {
        console.log(error);
        setBackdrop(false);
      });
  };

  const editListing = () => {
    let acc = account ? account : "";
    axios
      .get("https://dopewarz.frag-games.com/api/signedData")
      .then(function (response: any) {
        web3.eth.personal
          .sign(web3.utils.toHex(response.data.signedData.data), acc, "")
          .then(function (receipt: any) {
            let url =
              "https://dopewarz.frag-games.com/api/listForSale/update-listing";
            let payload = {
              tokenId: cards.nft._id,
              wallet: account,
              price: listingPrice,
              signature: receipt,
              signingDataId: response.data.signedData._id,
            };
            axios
              .post(url, payload)
              .then(function (response: any) {
                console.log(response);
                history.push("/blackmarket");
                setBackdrop(false);
              })
              .catch(function (error) {
                console.log(error);
                setBackdrop(false);
              });
          })
          .finally(() => {
            setBackdrop(false);
          });
      })
      .catch(function (error) {
        console.log(error);
        setBackdrop(false);
      });
  };
  const cancelListing = () => {
    let acc = account ? account : "";
    axios
      .get("https://dopewarz.frag-games.com/api/signedData")
      .then(function (response: any) {
        web3.eth.personal
          .sign(web3.utils.toHex(response.data.signedData.data), acc, "")
          .then(function (receipt: any) {
            let url =
              "https://dopewarz.frag-games.com/api/listForSale/delete-listing";
            let payload = {
              tokenId: cards.nft._id,
              wallet: account,
              signature: receipt,
              signingDataId: response.data.signedData._id,
            };
            axios
              .post(url, payload)
              .then(function (response: any) {
                console.log(response);
                history.push("/blackmarket");
              })
              .catch(function (error) {
                console.log(error);
              });
          })
          .finally(() => {
            setBackdrop(false);
          });
      })
      .catch(function (error) {
        console.log(error);
        setBackdrop(false);
      });
  };

  return (
    <>
      <CssBaseline />
      <div style={sectionStyle}>
        <Container maxWidth="xl" className="pageMaxSize">
          <Box
            sx={{
              display: "flex",

              height: "100%",
              pt: 6,
            }}
          >
            <Grid container>
              <Grid item md={12} sm={12}>
                <Alert
                  severity="info"
                  sx={{
                    color: "white",
                    fontFamily: "ThaleahFat",
                    fontSize: "26px",
                    border: `3px solid #0b0c14`,
                    borderRadius: 3,
                    backgroundColor: "#040508",
                    marginTop: "auto",
                    marginBottom: "auto",
                    "& .MuiAlert-icon": {
                      marginTop : "auto",
                      marginBottom : "auto",
                      padding: "none"
                    }
                  }}
                >
                  Buying/Selling is disabled until we launch our NFTs in July, hold tight!
                </Alert>
              </Grid>
              <Grid item md={8} sm={12}>
                <Paper
                  sx={{
                    backgroundColor: "transparent",
                    position: "relative",
                    pt: 4,

                    pb: 3,
                  }}
                >
                  {/* image here */}
                  <Box sx={{ flexGrow: 1 }}>
                    <Grid container spacing={1}>
                      <Grid container spacing={1}>
                        <div
                          onClick={handleClick}
                          style={{
                            marginBottom: "25px",
                            color: "#97a4b0",
                            cursor: "pointer",
                          }}
                        >
                          <i className="fas fa-chevron-left" />
                          <span
                            style={{
                              marginLeft: "6px",
                              fontFamily: "ThaleahFat",
                              fontSize: "24px",
                            }}
                          >
                            {" "}
                            Back
                          </span>
                        </div>
                      </Grid>
                      <Chip
                        label={cards.nft._id}
                        size="small"
                        sx={{
                          backgroundColor: "#ef8701",
                          color: "black",
                          p: 0,
                          fontSize: "12px",
                          maxWidth: "100px",
                          minWidth: "100px",
                          overflow: "hidden",
                          borderRadius: "8px",
                        }}
                      />
                      <Grid container spacing={1} sx={{ pl: 1, pt: 3 }}>
                        <Typography
                          sx={{
                            marginBottom: "10px",
                            color: "white !important",
                          }}
                        >
                          {" "}
                          {cards.nft.name}
                        </Typography>
                        {cards.nft.type === "Blockz" ? (
                          <Typography
                            sx={{
                              marginBottom: "10px",
                              marginLeft: "20px",
                              color: "#97a4b0 !important",
                            }}
                          >
                            {" "}
                            New York
                          </Typography>
                        ) : (
                          <></>
                        )}
                        {/* <Typography
                      sx={{
                        marginBottom: "10px",
                        marginLeft: "20px",
                        color: "#97a4b0 !important",
                      }}
                    >
                      {" "}
                      New York
                    </Typography> */}
                      </Grid>

                      <Grid
                        container
                        spacing={1}
                        sx={{ justifyContent: "center", alignItems: "center" }}
                      >
                        <NftImg img={cards.nft.image} type={cards.nft.type} />
                        {/* <img
                      src={cards.nft.image}
                      style={{
                        marginTop: "20px",
                        height: "470px",
                        width: "681px",
                      }} 
                    ></img>*/}
                      </Grid>
                    </Grid>
                  </Box>
                </Paper>
              </Grid>
              <Grid item md={4} sm={12}>
                <Paper
                  sx={{
                    backgroundColor: "transparent",
                    position: "relative",
                    pt: 4,
                    pl: 0,
                    pr: 1,
                    pb: 3,
                  }}
                >
                  <Box sx={{ flexGrow: 1, margin: "5px", textAlign: "left" }}>
                    <Grid container spacing={1} sx={{ margin: 0 }}>
                      {preLaunchEnabled ? (
                        <></>
                      ) : (
                        <BuyAndSell
                          cards={cards}
                          ownerAddress={cards.nft.ownerAddress}
                          account={account}
                          buyNFT={buyNft}
                          listForSale={setOpenListForSale}
                          editListing={setOpenEditListing}
                          cancelListing={cancelListing}
                          setBackdrop={setBackdrop}
                        />
                      )}
                    </Grid>
                    <DynamicInfo cards={cards} type={type} />
                    {/* type === "Blockz" ? (
                  <BlockzInfo cards={cards} />
                ) : (
                  <DopezInfo cards={cards} />
                ) */}

                    <SalesHistory transactionHistory={transactionHistory} />
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          </Box>
          <Dialog
            open={open}
            onClose={handleClose}
            sx={{
              "& .MuiDialog-paper": {
                backgroundColor: "#06070b",
                border: "1px solid grey",
              },
            }}
          >
            <DialogTitle>List for sale</DialogTitle>
            <DialogContent>
              <DialogContentText>
                Please enter the price to list the NFT for Sale
              </DialogContentText>
              <TextField
                autoFocus
                margin="dense"
                id="name"
                label="Price"
                type="number"
                fullWidth
                variant="outlined"
              />
            </DialogContent>
            <DialogActions>
              <Button
                onClick={handleClose}
                variant="outlined"
                color="error"
                sx={{ margin: "10px" }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleClose}
                variant="outlined"
                color="success"
                sx={{ margin: "10px" }}
              >
                List
              </Button>
            </DialogActions>
          </Dialog>
          <EditListing
            listingPrice={listingPrice}
            handlePriceChange={handlePriceChange}
            openListForSale={openListForSale}
            handleCloseListForSale={handleCloseListForSale}
            action={listForSale}
          />
          <EditListing
            listingPrice={listingPrice}
            handlePriceChange={handlePriceChange}
            openListForSale={openEditListing}
            handleCloseListForSale={handleCloseEditListing}
            action={editListing}
          />
          <Backdrop
            sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
            open={backdrop}
          >
            <CircularProgress color="inherit" />
          </Backdrop>
        </Container>
      </div>
      <OrderSuccess open={buySuccess} setOpen={setBuySuccess} />
    </>
  );
}
