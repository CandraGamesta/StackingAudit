import * as React from "react";
import Card from "@mui/material/Card";
import { Typography } from "@mui/material";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import axios from "axios";
import { useAuth } from "../hooks/web3Auth";

interface Column {
  id:
    | "TokenID"
    | "PurchaseDate"
    | "Price"
    | "PreviousOwner"
    | "TransactionType";
  label: string;
  minWidth?: number;
  align?: "right";
  format?: (value: number) => string;
}

const columns: readonly Column[] = [
  { id: "TokenID", label: "Token ID", minWidth: 100 },
  { id: "PurchaseDate", label: "Purchase Date", minWidth: 100 },
  {
    id: "Price",
    label: "Price",
    minWidth: 100,
    align: "right",
    format: (value: number) => value.toLocaleString("en-US"),
  },
  {
    id: "PreviousOwner",
    label: "Previous Owner",
    minWidth: 170,
    align: "right",
    format: (value: number) => value.toLocaleString("en-US"),
  },
  {
    id: "TransactionType",
    label: "Transaction Type",
    minWidth: 170,
    align: "right",
  },
];

interface Data {
  TokenID: string;
  PurchaseDate: string;
  Price: number;
  PreviousOwner: string;
  TransactionType: string;
}

function createData(
  TokenID: string,
  PurchaseDate: string,
  Price: number,
  seller: string,
  buyer: string,
  account: any
): Data {
  let PreviousOwner = "";
  let TransactionType = "";
  if (account === seller) {
    PreviousOwner = account;
    TransactionType = "Sold";
  } else {
    PreviousOwner = seller;
    TransactionType = "Bought";
  }
  return { TokenID, PurchaseDate, Price, PreviousOwner, TransactionType };
}

const defaultRows: any = [];

export default function AccountHistory() {
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [rows, setRows] = React.useState(defaultRows);
  const { account } = useAuth();
  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  React.useEffect(() => {
    let url: string;
    url = "https://dopewarz.frag-games.com/api/transactions/wallet";
    let payload = {
      wallet: account,
    };
    axios
      .post(url, payload)
      .then(function (response: any) {
        console.log(response);
        let data: any = [];
        response.data.transactions.map((tran: any) => {
          return data.push(
            createData(
              tran.nft.tokenId.toString(),
              new Date(tran.createdAt).toDateString(),
              tran.price,
              tran.seller,
              tran.buyer,
              account
            )
          );
        });
        setRows(data);
      })
      .catch(function (error) {
        console.log(error);
      });
  }, [account]);

  return ( <>
    <Typography
          sx={{
            fontFamily: "ThaleahFat",
            fontSize: "34px",
            color: "#97a4b0",
            mt: 5,
          }}
        >
          Account History
        </Typography>
    <Card
      sx={{
        width: "80%",
        overflow: "hidden",
        ml: "10%",
        mr: "10%",
        border: "1px solid rgba( 255 , 255 , 255 , 0.75 )",
        mt: 5,
        backgroundColor: "transparent !important",
        textAlign: "left",
      }}
    >
      
      <TableContainer>
        <Table stickyHeader>
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                  sx={{
                    minWidth: column.minWidth,
                    backgroundColor: "transparent",
                  }}
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row: any) => {
                return (
                  <TableRow
                    hover
                    role="checkbox"
                    tabIndex={-1}
                    key={row.TokenID}
                  >
                    {columns.map((column) => {
                      const value = row[column.id];
                      return (
                        <TableCell key={column.id}>
                          {column.format && typeof value === "number"
                            ? column.format(value)
                            : value}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                );
              })}
          </TableBody>
        </Table>
        <TablePagination
        rowsPerPageOptions={[10, 25, 100]}
        component="div"
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
        SelectProps={{MenuProps : {sx : { "& .MuiPaper-root" : {backgroundColor: "#000000"}}}}}
        
      />
      </TableContainer>
      
    </Card>
    </>
  );
}
