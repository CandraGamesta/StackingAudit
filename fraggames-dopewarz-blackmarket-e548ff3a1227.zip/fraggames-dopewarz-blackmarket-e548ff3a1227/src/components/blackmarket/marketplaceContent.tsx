import { useState, useMemo, useEffect } from "react";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import Divider from "@mui/material/Divider";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import PaginationItem from "@mui/material/PaginationItem";
import FormRow from "../blackmarket/Filters/Filters";
import DopezFilters from "./Filters/DopezFilters";
import DynamicCard from "../card/dynamicCard";
import axios from "axios";
import DynamicFilter from "./Filters/DynamicFilter";
import DopezGender from "./Filters/DopezGender";
import { Typography } from "@mui/material";
export default function MarketplaceContent(props: any) {
  const [cardsFromApi, setCardsFromApi] = useState([]);
  const [cards, setCards] = useState([]);
  //state for price filter
  const [maxPrice, setMaxPrice] = useState(0);
  const [priceFilter, setPriceFilter] = useState([1, 100]);

  //state for drugzCapacity
  const [maxDruzCapacity, setMaxDruzCapacity] = useState(0);
  const [druzCapacityFilter, setDruzCapacityFilter] = useState([1, 100]);

  //states for blockz stats

  //state for population
  const [maxPopulation, setMaxPopulation] = useState(0);
  const [populationFilter, setPopulationFilter] = useState([1, 100]);
  //state for heat
  const [maxHeat, setMaxHeat] = useState(0);
  const [heatFilter, setHeatFilter] = useState([1, 100]);
  // state for transport
  const [maxTransport, setMaxTransport] = useState(0);
  const [transportFilter, setTransportFilter] = useState([1, 100]);
  // state for economy
  const [maxEconomy, setMaxEconomy] = useState(0);
  const [economyFilter, setEconomyFilter] = useState([1, 100]);

  //states for dopez stats
  //state for power
  const [maxPower, setMaxPower] = useState(0);
  const [powerFilter, setPowerFilter] = useState([1, 100]);
  //state for respect
  const [maxRespect, setMaxRespect] = useState(0);
  const [respectFilter, setRespectFilter] = useState([1, 100]);
  //state for skill
  const [maxSkill, setMaxSkill] = useState(0);
  const [skillFilter, setSkillFilter] = useState([1, 100]);
  //state for cunning
  const [maxCunning, setMaxCunning] = useState(0);
  const [cunningFilter, setCunningFilter] = useState([1, 100]);

  //state for block size
  const [blockzSize, setBlockzSize] = useState(() => [
    "Small",
    "Medium",
    "Large",
  ]);

  const handleSizeChange = (
    event: React.MouseEvent<HTMLElement>,
    newSizes: string[]
  ) => {
    setBlockzSize(newSizes);
  };

  const [dopezGender, setDopezGender] = useState(() => ["Male", "Female"]);

  const handleGenderChange = (
    event: React.MouseEvent<HTMLElement>,
    newGenders: string[]
  ) => {
    setDopezGender(newGenders);
  };
  const [dopezRarity, setDopezRarity] = useState(() => [
    "Common",
    "Rare",
    "Og",
  ]);

  const handleRarityChange = (
    event: React.MouseEvent<HTMLElement>,
    newGenders: string[]
  ) => {
    setDopezRarity(newGenders);
  };

  //state for block type
  const [blockzType, setBlockzType] = useState({
    Basic: true,
    Landmark: true,
  });

  const handleTypeChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setBlockzType({
      ...blockzType,
      [event.target.name]: event.target.checked,
    });
  };

  useEffect(() => {
    let url: string;
    if (props.path === "market") {
      url = "https://dopewarz.frag-games.com/api/listForSale/get-all";
      axios
        .get(url)
        .then(function (response: any) {
          console.log(response);
          let cardsWithType = response.data.nfts.filter((crd: any) => {
            return crd.nft.type === props.type;
          });
          console.table(cardsWithType);
          setCardsFromApi(cardsWithType);
          setCards(cardsWithType);
          let max = Math.max.apply(
            Math,
            cardsWithType.map((o: any) => {
              return o.price;
            })
          );
          console.log("max price is:" + max);
          setMaxPrice(max);
          setPriceFilter([1, max]);
          if (props.type === "Blockz") {
            let maxCap = Math.max.apply(
              Math,
              cardsWithType.map((o: any) => {
                return o.nft.metadata.populationLevel;
              })
            );
            setMaxPopulation(maxCap);
            setPopulationFilter([1, maxCap]);
            maxCap = Math.max.apply(
              Math,
              cardsWithType.map((o: any) => {
                return o.nft.metadata.heatLevel;
              })
            );
            setMaxHeat(maxCap);
            setHeatFilter([1, maxCap]);
            maxCap = Math.max.apply(
              Math,
              cardsWithType.map((o: any) => {
                return o.nft.metadata.transportLevel;
              })
            );
            setMaxTransport(maxCap);
            setTransportFilter([1, maxCap]);
            maxCap = Math.max.apply(
              Math,
              cardsWithType.map((o: any) => {
                return o.nft.metadata.economyClass;
              })
            );

            setMaxEconomy(maxCap);
            setEconomyFilter([1, maxCap]);
          } else if (props.type === "Dopez") {
            let maxCap = Math.max.apply(
              Math,
              cardsWithType.map((o: any) => {
                return o.nft.metadata.power;
              })
            );
            setMaxPower(maxCap);
            setPowerFilter([1, maxCap]);
            maxCap = Math.max.apply(
              Math,
              cardsWithType.map((o: any) => {
                return o.nft.metadata.respect;
              })
            );
            setMaxRespect(maxCap);
            setRespectFilter([1, maxCap]);
            maxCap = Math.max.apply(
              Math,
              cardsWithType.map((o: any) => {
                return o.nft.metadata.skill;
              })
            );
            setMaxSkill(maxCap);
            setSkillFilter([1, maxCap]);
            maxCap = Math.max.apply(
              Math,
              cardsWithType.map((o: any) => {
                return o.nft.metadata.cunning;
              })
            );

            setMaxCunning(maxCap);
            setCunningFilter([1, maxCap]);
          } else if (props.type === "Doz") {
            let maxCap = Math.max.apply(
              Math,
              cardsWithType.map((o: any) => {
                return o.nft.metadata.drugCapacity;
              })
            );
            console.log("max capacity is:" + maxCap);
            setMaxDruzCapacity(maxCap);
            setDruzCapacityFilter([1, maxCap]);
          }
        })
        .catch(function (error) {
          console.log(error);
        });
    } else {
      if (props.account) {
        url = "https://dopewarz.frag-games.com/api/nfts/nft-by-wallet";
        let payload = {
          wallet: props.account,
        };
        axios
          .post(url, payload)
          .then(function (response: any) {
            console.log(response);
            let cardsWithType = response.data.nfts.filter((crd: any) => {
              return crd.nft.type === props.type;
            });
            console.table(cardsWithType);
            setCardsFromApi(cardsWithType);
            console.log(cardsWithType);
            setCards(cardsWithType);
            let max = Math.max.apply(
              Math,
              cardsWithType.map((o: any) => {
                if(typeof(o.price)==="number"){
                  return o.price;
                }else {
                  return 0;
                }
                
              })
            );
            console.log("max price is:" + max);
            setMaxPrice(max);
            setPriceFilter([1, max]);

            if (props.type === "Blockz") {
              let maxCap = Math.max.apply(
                Math,
                cardsWithType.map((o: any) => {
                  return o.nft.metadata.populationLevel;
                })
              );
              setMaxPopulation(maxCap);
              setPopulationFilter([1, maxCap]);
              maxCap = Math.max.apply(
                Math,
                cardsWithType.map((o: any) => {
                  return o.nft.metadata.heatLevel;
                })
              );
              setMaxHeat(maxCap);
              setHeatFilter([1, maxCap]);
              maxCap = Math.max.apply(
                Math,
                cardsWithType.map((o: any) => {
                  return o.nft.metadata.transportLevel;
                })
              );
              setMaxTransport(maxCap);
              setTransportFilter([1, maxCap]);
              maxCap = Math.max.apply(
                Math,
                cardsWithType.map((o: any) => {
                  return o.nft.metadata.economyClass;
                })
              );

              setMaxEconomy(maxCap);
              setEconomyFilter([1, maxCap]);
            } else if (props.type === "Doz") {
              let maxCap = Math.max.apply(
                Math,
                cardsWithType.map((o: any) => {
                  return o.nft.metadata.drugCapacity;
                })
              );
              console.log("max capacity is:" + maxCap);
              setMaxDruzCapacity(maxCap);
              setDruzCapacityFilter([1, maxCap]);
            }
          })
          .catch(function (error) {
            console.log(error);
          });
      }
    }
  }, [props.account]);
  //filter for price slider
  useEffect(() => {
    let cardsFiltered: any = [];
    if (props.type == "Blockz") {
      cardsFiltered = cardsFromApi.filter((card: any) => {
        return (
          card.price >= priceFilter[0] &&
          card.price <= priceFilter[1] &&
          card.nft.metadata.populationLevel >= populationFilter[0] &&
          card.nft.metadata.populationLevel <= populationFilter[1] &&
          card.nft.metadata.heatLevel >= heatFilter[0] &&
          card.nft.metadata.heatLevel <= heatFilter[1] &&
          card.nft.metadata.transportLevel >= transportFilter[0] &&
          card.nft.metadata.transportLevel <= transportFilter[1] &&
          card.nft.metadata.economyClass >= economyFilter[0] &&
          card.nft.metadata.economyClass <= economyFilter[1] &&
          blockzSize.includes(card.nft.metadata.size)
        );
      });

      if (blockzType.Basic && blockzType.Landmark) {
        cardsFiltered = cardsFiltered.filter((card: any) => {
          return (
            card.nft.metadata.typeOfBlockz == "Basic" ||
            card.nft.metadata.typeOfBlockz == "Landmark"
          );
        });
      } else if (blockzType.Basic) {
        cardsFiltered = cardsFiltered.filter((card: any) => {
          return card.nft.metadata.typeOfBlockz == "Basic";
        });
      } else if (blockzType.Landmark) {
        cardsFiltered = cardsFiltered.filter((card: any) => {
          return card.nft.metadata.typeOfBlockz == "Landmark";
        });
      }
    } else if (props.type == "Dopez") {
      console.log("mpcc inside type dopez");
      cardsFiltered = cardsFromApi.filter((card: any) => {
        return (
          card.price >= priceFilter[0] &&
          card.price <= priceFilter[1] &&
          card.nft.metadata.power >= powerFilter[0] &&
          card.nft.metadata.power <= powerFilter[1] &&
          card.nft.metadata.respect >= respectFilter[0] &&
          card.nft.metadata.respect <= respectFilter[1] &&
          card.nft.metadata.skill >= skillFilter[0] &&
          card.nft.metadata.skill <= skillFilter[1] &&
          card.nft.metadata.cunning >= cunningFilter[0] &&
          card.nft.metadata.cunning <= cunningFilter[1] &&
          dopezGender.includes(card.nft.metadata.gender) &&
          dopezRarity.includes(card.nft.metadata.rarity)
        );
      });
    } else {
      cardsFiltered = cardsFromApi.filter((card: any) => {
        return (
          card.price >= priceFilter[0] &&
          card.price <= priceFilter[1] &&
          card.nft.metadata.drugCapacity >= druzCapacityFilter[0] &&
          card.nft.metadata.drugCapacity <= druzCapacityFilter[1]
        );
      });
    }

    setCards(cardsFiltered);
    console.log("mpcc:"+cardsFiltered.length);
  }, [
    priceFilter,
    blockzSize,
    blockzType,
    dopezGender,
    dopezRarity,
    druzCapacityFilter,
    populationFilter,
    heatFilter,
    transportFilter,
    economyFilter,
    powerFilter,
    skillFilter,
    respectFilter,
    cunningFilter,
  ]);

  const [page, setPage] = useState<number>(1);

  const pageSize = 15;
  const totalPages = useMemo(() => {
    return Math.ceil(cards.length / pageSize);
  }, [cards, pageSize]);

  const cardsToShow = useMemo(() => {
    const startIndex = (page - 1) * pageSize;
    const endIndex = page * pageSize;
    return cards.slice(startIndex, endIndex);
  }, [cards, page, pageSize]);
  const handlePageChange = (event: any, value: any) => {
    setPage(value);
  };
  return (
    <Box
      sx={{
        display: "flex",
        width: "100%",
        border: (theme) => `1px solid ${theme.palette.divider}`,
        borderRadius: 1,
      }}
    >
      <Paper
        sx={{
          backgroundColor: "transparent",
          position: "relative",
          pt: 4,
          pl: 2,
          pb: 3,
          minWidth: { md: "18rem", lg: "18rem", xl: "16rem" },
          maxWidth: { md: "18rem", lg: "18rem", xl: "16rem" },
          display: {
            xs: "none",
            md: "block",
          },
        }}
      >
        <Box sx={{ flexGrow: 1 }}>
          <Grid container spacing={1}>
            <Grid container item spacing={3}>
              <DynamicFilter
                type={props.type}
                priceFilter={priceFilter}
                setPriceFilter={setPriceFilter}
                maxPrice={maxPrice}
                blockzSize={blockzSize}
                setBlockzSize={handleSizeChange}
                blockzType={blockzType}
                setBlockzType={handleTypeChange}
                dopezGender={dopezGender}
                setDopezGender={handleGenderChange}
                dopezRarity={dopezRarity}
                setDopezRarity={handleRarityChange}
                druzCapacityFilter={druzCapacityFilter}
                setDruzCapacityFilter={setDruzCapacityFilter}
                maxDruzCapacity={maxDruzCapacity}
                populationFilter={populationFilter}
                setPopulationFilter={setPopulationFilter}
                maxPopulation={maxPopulation}
                heatFilter={heatFilter}
                setHeatFilter={setHeatFilter}
                maxHeat={maxHeat}
                transportFilter={transportFilter}
                setTransportFilter={setTransportFilter}
                maxTransport={maxTransport}
                economyFilter={economyFilter}
                setEconomyFilter={setEconomyFilter}
                maxEconomy={maxEconomy}
                powerFilter={powerFilter}
                setPowerFilter={setPowerFilter}
                maxPower={maxPower}
                respectFilter={respectFilter}
                setRespectFilter={setRespectFilter}
                maxRespect={maxRespect}
                skillFilter={skillFilter}
                setSkillFilter={setSkillFilter}
                maxSkill={maxSkill}
                cunningFilter={cunningFilter}
                setCunningFilter={setCunningFilter}
                maxCunning={maxCunning}
              />
              {/* props.type === "Blockz" ? (
                <FormRow
                  priceFilter={priceFilter}
                  setPriceFilter={setPriceFilter}
                  maxPrice={maxPrice}
                  blockzSize={blockzSize}
                  setBlockzSize={handleSizeChange}
                  blockzType={blockzType}
                  setBlockzType={handleTypeChange}
                />
              ) : (
                <DopezFilters
                  priceFilter={priceFilter}
                  setPriceFilter={setPriceFilter}
                  maxPrice={maxPrice}
                  dopezGender={dopezGender}
                  setDopezGender={handleGenderChange}
                  dopezRarity={dopezRarity}
                  setDopezRarity={handleRarityChange}
                />
              ) */}
            </Grid>
          </Grid>
        </Box>
      </Paper>

      <Divider orientation="vertical" flexItem />
      <Paper
        sx={{
          backgroundColor: "transparent",
          position: "relative",
          pt: 4,
          pb: 3,
          width: { md: "80%", xs: "100%", xl: "90%" },
        }}
      >
        <Grid
          container
          justifyContent="center"
          columnSpacing={{ xs: 1, sm: 2, md: 0.01 }}
          rowSpacing={{ xs: 2, sm: 3, md: 4 }}
          alignItems="center"
        >
          {cardsToShow.map((card, cardIdx) => (
            <Grid item key={`pool-card-${cardIdx}`}>
              <DynamicCard type={props.type} card={card} />
            </Grid>
          ))}
          <Grid item xs={12} />
          {cardsToShow.length > 0 ? <Stack spacing={2}>
            <Pagination
              count={totalPages}
              page={page}
              onChange={handlePageChange}
              renderItem={(item) => (
                <PaginationItem sx={{ color: "whitesmoke" }} {...item} />
              )}
            />
          </Stack> : <Typography sx={{ minWidth : "100% !important", justifyContent : "center", margin : "auto"}}>No Matching NFT Found</Typography>}
          {/* <Stack spacing={2}>
            <Pagination
              count={totalPages}
              page={page}
              onChange={handlePageChange}
              renderItem={(item) => (
                <PaginationItem sx={{ color: "whitesmoke" }} {...item} />
              )}
            />
          </Stack> */}
        </Grid>
        
      </Paper>
    </Box>
  );
}
