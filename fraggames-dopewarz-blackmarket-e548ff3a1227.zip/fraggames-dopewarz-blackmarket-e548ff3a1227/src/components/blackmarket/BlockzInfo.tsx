import { useState } from "react";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Avatar from "@mui/material/Avatar";
import { Typography } from "@mui/material";
import { useHistory } from "react-router-dom";
import PopulationIcon from "../../assets/blackmarket/Population-icon.png";
import EconomyIcon from "../../assets/blackmarket/Economy-icon.png";
import TransportIcon from "../../assets/blackmarket/Transport-icon.png";
import HeatIcon from "../../assets/blackmarket/Heat-icon.png";

export default function BlockzInfo(props: any) {
  const [cards, setCards] = useState(props.cards);
  let history = useHistory();

  return (
    <>
      <Grid container spacing={1} sx={{ margin: "5px" }}>
        <Typography
          sx={{
            fontFamily: "ThaleahFat",
            fontSize: "26px",
            color: "#97a4b0",
          }}
        >
          About
        </Typography>
      </Grid>
      <Grid
        container
        alignItems="center"
        justifyContent="center"
        sx={{
          width: "100%",
          border: `3px solid #0b0c14`,
          borderRadius: 3,
          backgroundColor: "#040508",
          color: "white",
          textAlign: "left",
          p: 2,
        }}
      >
        <Grid item md={4} sm={4} xs={4}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
            }}
          >
            Size
          </Typography>
        </Grid>
        <Grid item md={4} sm={4} xs={4}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
            }}
          >
            Type
          </Typography>
        </Grid>
        <Grid item md={4} sm={4} xs={4}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
            }}
          >
            # of Doz
          </Typography>
        </Grid>

        <Grid item md={4} sm={4} xs={4}>
          <Typography sx={{ fontSize: "14px" }}>
            {cards.nft.metadata.size}
          </Typography>
        </Grid>
        <Grid item md={4} sm={4} xs={4}>
          <Typography sx={{ fontSize: "14px" }}>
            {cards.nft.metadata.typeOfBlockz}
          </Typography>
        </Grid>
        <Grid item md={4} sm={4} xs={4}>
          <Typography sx={{ fontSize: "14px" }}>
            {cards.nft.metadata.noOfDoz}
          </Typography>
        </Grid>

        <Grid item md={6}  sm={6} xs={6} sx={{ pt: 3 }}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
            }}
          >
            Drugz Demand
          </Typography>
        </Grid>
        <Grid item md={6}sm={6} xs={6} sx={{ pt: 3 }}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
            }}
          >
            Drugz Supply
          </Typography>
        </Grid>
        <Grid item md={6} sm={6} xs={6}>
          <Typography sx={{ fontSize: "14px" }}>
            {cards.nft.metadata.demandDrugz.map((drug: String, index : number) => {
              if(index === cards.nft.metadata.demandDrugz.length-1){
                return drug;
              }else {
                return drug + ", ";
              }
              
            })}
          </Typography>
        </Grid>
        <Grid item md={6} sm={6} xs={6}>
          <Typography sx={{ fontSize: "14px" }}>
            {cards.nft.metadata.supplyDrugz.map((drug: String, index : number) => {
              if(index === cards.nft.metadata.supplyDrugz.length-1){
                return drug;
              }else {
                return drug + ", ";
              }
            })}
          </Typography>
        </Grid>

        <Grid item md={12} sm={12} xs={12}sx={{ pt: 3, overflow: "hidden" }}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
              
            }}
          >
            Owner
          </Typography>
        </Grid>

        <Grid
          item
          md={12}
          sm={12} xs={12}
          onClick={() => {
            history.push({
              pathname: "/user/" + cards.nft.ownerAddress,
              state: { type: "Blockz" },
            });
            
          }}
        >
          <Typography sx={{ fontSize: "16px", cursor: "pointer", textOverflow: "ellipsis",
                          overflow: "hidden", }}>
            {cards.nft.ownerAddress}
          </Typography>
        </Grid>
      </Grid>

      <Grid container spacing={2} sx={{ margin: "5px" }}>
        <Typography
          sx={{
            fontFamily: "ThaleahFat",
            fontSize: "26px",
            color: "#97a4b0",
          }}
        >
          Statz
        </Typography>
      </Grid>
      <Grid
        container
        alignItems="center"
        justifyContent="center"
        sx={{
          width: "100%",
          border: `3px solid #0b0c14`,
          borderRadius: 3,
          backgroundColor: "#040508",
          color: "#97a4b0",
          textAlign: "left",
        }}
      >
        <Grid item md={3} sm={3} xs={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
              p: 1,
              m: 1,
            }}
          >
            <Typography sx={{ fontFamily: "ThaleahFat", fontSize: "22px" }}>
              Population
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "flex-start",
                flexDirection: "row",
              }}
            >
              <Avatar
                variant="square"
                alt="test avatar"
                src={PopulationIcon}
                sx={{ height: "24px", width: "26px" }}
              />
              <Typography
                sx={{
                  ml: 1,
                  mt: 0.3,
                  color: "white",
                  fontSize: "14px",
                }}
              >
                {cards.nft.metadata.populationLevel}
              </Typography>
            </Box>
          </Box>
        </Grid>
        <Grid item md={3} sm={3} xs={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
              p: 1,
              m: 1,
            }}
          >
            <Typography sx={{ fontFamily: "ThaleahFat", fontSize: "22px" }}>
              Heat
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "flex-start",
                flexDirection: "row",
              }}
            >
              <Avatar
                variant="square"
                alt="test avatar"
                src={HeatIcon}
                sx={{ height: "24px", width: "26px" }}
              />
              <Typography
                sx={{
                  ml: 1,
                  mt: 0.3,
                  color: "white",
                  fontSize: "14px",
                }}
              >
                {cards.nft.metadata.heatLevel}
              </Typography>
            </Box>
          </Box>
        </Grid>
        <Grid item md={3} sm={3} xs={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
              p: 1,
              m: 1,
            }}
          >
            <Typography sx={{ fontFamily: "ThaleahFat", fontSize: "22px" }}>
              Transport
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "flex-start",
                flexDirection: "row",
              }}
            >
              <Avatar
                variant="square"
                alt="test avatar"
                src={TransportIcon}
                sx={{ height: "24px", width: "26px" }}
              />
              <Typography
                sx={{
                  ml: 1,
                  mt: 0.3,
                  color: "white",
                  fontSize: "14px",
                }}
              >
                {cards.nft.metadata.transportLevel}
              </Typography>
            </Box>
          </Box>
        </Grid>
        <Grid item md={3} sm={3} xs={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
              p: 1,
              m: 1,
            }}
          >
            <Typography sx={{ fontFamily: "ThaleahFat", fontSize: "22px" }}>
              Economy
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "flex-start",
                flexDirection: "row",
              }}
            >
              <Avatar
                variant="square"
                alt="test avatar"
                src={EconomyIcon}
                sx={{ height: "24px", width: "26px" }}
              />
              <Typography
                sx={{
                  ml: 1,
                  mt: 0.3,
                  color: "white",
                  fontSize: "14px",
                }}
              >
                {cards.nft.metadata.economyClass}
              </Typography>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </>
  );
}
