import React from "react";

export default function NftImg(props: any) {
  let styles;
  if (props.type == "Dopez") {
    styles = {
      marginTop: "20px",
      height: "200%",
      width: "auto",
    };
  } else if (props.type == "Blockz") {
    styles = {
      marginTop: "20px",
      height: "470px",
      width: "681px",
    };
  }
  else if (props.type == "Doz") {
    styles = {
      marginTop: "20px",
      height: "100%",
      width: "50%",
    };
  }
  return <img src={props.img} style={styles}></img>;
}
