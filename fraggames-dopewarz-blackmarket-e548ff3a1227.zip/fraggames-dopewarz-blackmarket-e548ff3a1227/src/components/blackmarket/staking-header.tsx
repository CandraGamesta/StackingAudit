import React from 'react';
import Box from "@mui/material/Box";
import stakingHeader from "src/assets/blackmarket/Final_Banner.png"

export default function StakingHeader() {
  return (<>
  <Box sx={{width:"100%"}}>
<img src={stakingHeader} width={"100%"}/>
</Box>
    </>);
}
