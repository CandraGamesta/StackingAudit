import { useState } from "react";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Avatar from "@mui/material/Avatar";
import { Typography } from "@mui/material";
import { useHistory } from "react-router-dom";
import PopulationIcon from "../../assets/blackmarket/Population-icon.png";
import EconomyIcon from "../../assets/blackmarket/Economy-icon.png";
import TransportIcon from "../../assets/blackmarket/Transport-icon.png";
import HeatIcon from "../../assets/blackmarket/Heat-icon.png";
import SkillIcon from "../../assets/blackmarket/skill-icon.png";
import RespectIcon from "../../assets/blackmarket/Respect-icon.png";
import PowerIcon from "../../assets/blackmarket/Power-icon.png";
import CunningIcon from "../../assets/blackmarket/cunning-icon.png";
export default function DopezInfo(props: any) {
  const [cards, setCards] = useState(props.cards);
  let history = useHistory();

  return (
    <>
      <Grid container spacing={1} sx={{ margin: "5px" }}>
        <Typography
          sx={{
            fontFamily: "ThaleahFat",
            fontSize: "26px",
            color: "#97a4b0",
          }}
        >
          About
        </Typography>
      </Grid>
      <Grid
        container
        alignItems="center"
        justifyContent="center"
        sx={{
          width: "100%",
          border: `3px solid #0b0c14`,
          borderRadius: 3,
          backgroundColor: "#040508",
          color: "white",
          textAlign: "left",
          p: 2,
        }}
      >
        <Grid item md={4} sm={4} xs={4}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
            }}
          >
            Class
          </Typography>
        </Grid>
        <Grid item md={4} sm={4} xs={4}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
            }}
          >
            Gender
          </Typography>
        </Grid>
        <Grid item md={4} sm={4} xs={4}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
            }}
          >
            Rarity
          </Typography>
        </Grid>

        <Grid item md={4} sm={4} xs={4}>
          <Typography sx={{ fontSize: "14px" }}>
            {cards.nft.metadata.class}
          </Typography>
        </Grid>
        <Grid item md={4} sm={4} xs={4}>
          <Typography sx={{ fontSize: "14px" }}>
            {cards.nft.metadata.gender}
          </Typography>
        </Grid>
        <Grid item md={4} sm={4} xs={4}>
          <Typography sx={{ fontSize: "14px" }}>{cards.nft.metadata.rarity}</Typography>
        </Grid>

        <Grid item md={12} sm={12} xs={12} sx={{ pt: 3 }}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
            }}
          >
            Accessoriez
          </Typography>
        </Grid>

        <Grid item md={12} sm={12} xs={12}>
          <Typography sx={{ fontSize: "14px" }}>
            {cards.nft.metadata.accessoriez.map((acc: String, index : number) => {
             if(index === cards.nft.metadata.accessoriez.length-1){
              return acc;
            }else {
              return acc + ", ";
            }
            })}
          </Typography>
        </Grid>

        <Grid item md={12} sm={12} xs={12} sx={{ pt: 3, overflow: "hidden" }}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
            }}
          >
            Owner
          </Typography>
        </Grid>

        <Grid
          item
          md={12}
          sm={12} xs={12}
          onClick={() => {
            history.push({
              pathname: "/user/" + cards.nft.ownerAddress,
              state: { type: "Dopez" },
            });
          }}
        >
          <Typography sx={{ fontSize: "16px", cursor: "pointer", textOverflow: "ellipsis",
                          overflow: "hidden", }}>
            {cards.nft.ownerAddress}
          </Typography>
        </Grid>
      </Grid>

      <Grid container spacing={2} sx={{ margin: "5px" }}>
        <Typography
          sx={{
            fontFamily: "ThaleahFat",
            fontSize: "26px",
            color: "#97a4b0",
          }}
        >
          Statz
        </Typography>
      </Grid>
      <Grid
        container
        alignItems="center"
        justifyContent="center"
        sx={{
          width: "100%",
          border: `3px solid #0b0c14`,
          borderRadius: 3,
          backgroundColor: "#040508",
          color: "#97a4b0",
          textAlign: "left",
        }}
      >
        <Grid item md={3} sm={3} xs={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
              p: 1,
              m: 1,
            }}
          >
            <Typography sx={{ fontFamily: "ThaleahFat", fontSize: "22px" }}>
              Power
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "flex-start",
                flexDirection: "row",
              }}
            >
              <Avatar
                variant="square"
                alt="test avatar"
                src={PowerIcon}
                sx={{ height: "24px", width: "26px" }}
              />
              <Typography
                sx={{
                  ml: 1,
                  mt: 0.3,
                  color: "white",
                  fontSize: "14px",
                }}
              >
                {cards.nft.metadata.power}
              </Typography>
            </Box>
          </Box>
        </Grid>
        <Grid item md={3} sm={3} xs={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
              p: 1,
              m: 1,
            }}
          >
            <Typography sx={{ fontFamily: "ThaleahFat", fontSize: "22px" }}>
              Respect
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "flex-start",
                flexDirection: "row",
              }}
            >
              <Avatar
                variant="square"
                alt="test avatar"
                src={RespectIcon}
                sx={{ height: "24px", width: "26px" }}
              />
              <Typography
                sx={{
                  ml: 1,
                  mt: 0.3,
                  color: "white",
                  fontSize: "14px",
                }}
              >
                {cards.nft.metadata.respect}
              </Typography>
            </Box>
          </Box>
        </Grid>
        <Grid item md={3} sm={3} xs={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
              p: 1,
              m: 1,
            }}
          >
            <Typography sx={{ fontFamily: "ThaleahFat", fontSize: "22px" }}>
              Skill
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "flex-start",
                flexDirection: "row",
              }}
            >
              <Avatar
                variant="square"
                alt="test avatar"
                src={SkillIcon}
                sx={{ height: "24px", width: "26px" }}
              />
              <Typography
                sx={{
                  ml: 1,
                  mt: 0.3,
                  color: "white",
                  fontSize: "14px",
                }}
              >
                {cards.nft.metadata.skill}
              </Typography>
            </Box>
          </Box>
        </Grid>
        <Grid item md={3} sm={3} xs={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
              p: 1,
              m: 1,
            }}
          >
            <Typography sx={{ fontFamily: "ThaleahFat", fontSize: "22px" }}>
              Cunning
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "flex-start",
                flexDirection: "row",
              }}
            >
              <Avatar
                variant="square"
                alt="test avatar"
                src={CunningIcon}
                sx={{ height: "24px", width: "26px" }}
              />
              <Typography
                sx={{
                  ml: 1,
                  mt: 0.3,
                  color: "white",
                  fontSize: "14px",
                }}
              >
                {cards.nft.metadata.cunning}
              </Typography>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </>
  );
}
