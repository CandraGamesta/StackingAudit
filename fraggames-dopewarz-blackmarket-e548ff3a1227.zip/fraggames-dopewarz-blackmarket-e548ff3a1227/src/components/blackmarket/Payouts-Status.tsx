import * as React from "react";
import Card from "@mui/material/Card";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import axios from "axios";
import { useAuth } from "../hooks/web3Auth";
import { TableFooter } from "@mui/material";
interface Column {
  id: "NftID" | "Date" | "Status" | "Amount";
  label: string;
  minWidth?: number;
  align?: "right";
  format?: (value: number) => string;
}

const columns: readonly Column[] = [
  { id: "NftID", label: "Nft Id", minWidth: 50 },
  { id: "Date", label: "Date", minWidth: 50 },
  {
    id: "Status",
    label: "Status",
    minWidth: 50,
  },
  {
    id: "Amount",
    label: "Amount",
    minWidth: 50,
    format: (value: number) => value.toLocaleString("en-US"),
  },
];

interface Data {
  NftID: string;
  Date: string;
  Status: String;
  Amount: number;
}

function createData(
  NftID: string,
  Date: string,
  Status: String,
  Amount: number
): Data {
  return { NftID, Date, Status, Amount };
}

let defaultRows = [
  createData("1", "19th January, 2022 ", "Pending", 10),
  createData("2", "19th January, 2022 ", "Cleared", 10),
  createData("3", "19th January, 2022 ", "Pending", 10),
  createData("4", "19th January, 2022 ", "Cleared", 10),
  createData("5", "19th January, 2022 ", "Pending", 10),
  createData("6", "19th January, 2022 ", "Cleared", 10),
  createData("7", "19th January, 2022 ", "Pending", 10),
  createData("8", "19th January, 2022 ", "Cleared", 10),
  createData("9", "19th January, 2022 ", "Pending", 10),
  createData("10", "19th January, 2022 ", "Cleared", 10),
  createData("11", "19th January, 2022 ", "Pending", 10),
  createData("12", "19th January, 2022 ", "Cleared", 10),
  createData("13", "19th January, 2022 ", "Pending", 10),
];

export default function PayoutsStatus() {
  const [page, setPage] = React.useState(0);
  const [rows, setRows] = React.useState(defaultRows);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const { login, logout, account, chainId } = useAuth();
  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };
  React.useEffect(() => {
    let url: string;
    url = "https://dopewarz.frag-games.com/api/payouts/wallet";
    let payload = {
      wallet: account,
    };
    axios
      .post(url, payload)
      .then(function (response: any) {
        console.log(response);
        let data: any = [];
        response.data.payouts.map((pay: any) => {
          data.push(
            createData(
              pay.transaction.nft.tokenId.toString(),
              new Date(pay.createdAt).toDateString(),
              pay.status,
              pay.transaction.price
            )
          );
        });
        setRows(data);
      })
      .catch(function (error) {
        console.log(error);
      });
  }, []);

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };
  const getBorderColor = (status: any) => {
    if (status === "pending") {
      return "orange";
    } else {
      return "green";
    }
  };
  return (
    <>
      <Typography
        sx={{
          fontFamily: "ThaleahFat",
          fontSize: "34px",
          color: "#97a4b0",
          mt: 5,
        }}
      >
        Payouts Status
      </Typography>
      <Card
        sx={{
          width: "80%",
          overflow: "hidden",
          ml: "10%",
          mr: "10%",
          border: "1px solid rgba( 255 , 255 , 255 , 0.75 )",
          mt: 5,
          backgroundColor: "transparent",
          textAlign: "left",
        }}
      >
        <TableContainer>
          <Table stickyHeader
          sx={{
            ".MuiTablePagination-root": {
              backgroundColor: "black !important",
            },
            ".MuiTablePagination-select": {
              backgroundColor: "black !important",
            },
            ".MuiTablePagination-menuItem": {
              backgroundColor: "black !important",
            },
            ".MuiPaper-root": {
              backgroundColor: "#242735 !important",
            },
            ".MuiPopover-root" :{
              backgroundColor: "#242735 !important",
            }
          }}>
            <TableHead>
              <TableRow>
                {columns.map((column) => (
                  <TableCell
                    key={column.id}
                    sx={{
                      minWidth: column.minWidth,
                      backgroundColor: "transparent",
                    }}
                  >
                    {column.label}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {rows
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row) => {
                  return (
                    <TableRow
                      hover
                      role="checkbox"
                      tabIndex={-1}
                      key={row.NftID}
                    >
                      {columns.map((column) => {
                        const value = row[column.id];
                        return (
                          <TableCell key={column.id}>
                            <Box
                              sx={
                                column.label == "Status"
                                  ? {
                                      border:
                                        "1px solid " + getBorderColor(value),
                                      borderRadius: "5px",
                                    }
                                  : {}
                              }
                            >
                              <Typography sx={{ margin: "5px" }}>
                                {column.format && typeof value === "number"
                                  ? column.format(value)
                                  : value}
                              </Typography>
                            </Box>
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  );
                })}
            </TableBody>
            <TableFooter>
              <TablePagination
                rowsPerPageOptions={[10, 25, 100]}
                count={rows.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
                SelectProps={{MenuProps : {sx : { "& .MuiPaper-root" : {backgroundColor: "#000000"}}}}}
                
              />
            </TableFooter>
          </Table>
        </TableContainer>
      </Card>
    </>
  );
}
