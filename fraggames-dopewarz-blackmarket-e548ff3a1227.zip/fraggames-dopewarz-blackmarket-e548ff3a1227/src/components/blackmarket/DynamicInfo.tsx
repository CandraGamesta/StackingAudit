import React from 'react'
import DopezInfo from './DopezInfo'
import BlockzInfo from './BlockzInfo'
import DozInfo from './DozInfo'
export default function DynamicInfo(props : any) {
    if (props.type == "Dopez") {
        return <DopezInfo cards={props.cards} />;
      } else if (props.type == "Blockz") {
        return <BlockzInfo cards={props.cards} />;
      } else if (props.type == "Doz"){
        return <DozInfo cards={props.cards} />;
      }else {
        return <></>;
      }
}
