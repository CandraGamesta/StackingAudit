import React from "react";
import Filters from "./Filters";
import DopezFilters from "./DopezFilters";
import DozFilters from "./DozFilters";
export default function DynamicFilter(props: any) {
  if (props.type === "Blockz") {
    return (
      <Filters
        priceFilter={props.priceFilter}
        setPriceFilter={props.setPriceFilter}
        maxPrice={props.maxPrice}
        blockzSize={props.blockzSize}
        setBlockzSize={props.setBlockzSize}
        blockzType={props.blockzType}
        setBlockzType={props.setBlockzType}
        populationFilter={props.populationFilter}
        setPopulationFilter={props.setPopulationFilter}
        maxPopulation={props.maxPopulation}
        heatFilter={props.heatFilter}
        setHeatFilter={props.setHeatFilter}
        maxHeat={props.maxHeat}
        transportFilter={props.transportFilter}
        setTransportFilter={props.setTransportFilter}
        maxTransport={props.maxTransport}
        economyFilter={props.economyFilter}
        setEconomyFilter={props.setEconomyFilter}
        maxEconomy={props.maxEconomy}
      />
    );
  } else if (props.type === "Dopez") {
    return (
      <DopezFilters
        priceFilter={props.priceFilter}
        setPriceFilter={props.setPriceFilter}
        maxPrice={props.maxPrice}
        dopezGender={props.dopezGender}
        setDopezGender={props.setDopezGender}
        dopezRarity={props.dopezRarity}
        setDopezRarity={props.setDopezRarity}

        powerFilter={props.powerFilter}
        setPowerFilter={props.setPowerFilter}
        maxPower={props.maxPower}
        respectFilter={props.respectFilter}
        setRespectFilter={props.setRespectFilter}
        maxRespect={props.maxRespect}
        skillFilter={props.skillFilter}
        setSkillFilter={props.setSkillFilter}
        maxSkill={props.maxSkill}
        cunningFilter={props.cunningFilter}
        setCunningFilter={props.setCunningFilter}
        maxCunning={props.maxCunning}
      />
    );
  } else if (props.type === "Doz") {
    return (
      <DozFilters
        priceFilter={props.priceFilter}
        setPriceFilter={props.setPriceFilter}
        maxPrice={props.maxPrice}
        druzCapacityFilter={props.druzCapacityFilter}
        setDruzCapacityFilter={props.setDruzCapacityFilter}
        maxDruzCapacity={props.maxDruzCapacity}
      />
    );
  } else {
    return <></>;
  }
}
