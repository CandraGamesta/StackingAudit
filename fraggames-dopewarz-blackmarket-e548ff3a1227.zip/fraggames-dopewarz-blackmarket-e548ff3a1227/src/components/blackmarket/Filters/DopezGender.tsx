import Box from "@mui/material/Box";
import ToggleButton from "@mui/material/ToggleButton";
import Typography from "@mui/material/Typography";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import Avatar from "@mui/material/Avatar";
import Male from "../../../assets/blackmarket/Male-selected.png";
import Female from "../../../assets/blackmarket/Female-selected.png";

export default function DopezGender(props: any) {
  return (
    <Box sx={{ display: "flex" }}>
      <ToggleButtonGroup
        value={props.blockzSize}
        onChange={props.setBlockzSize}
        color="primary"
        sx={{
          "& .MuiToggleButtonGroup-grouped": {
            color: "primary",
            backgroundColor: "#8600d4 !important",
          },
        }}
      >
        <ToggleButton
          value="Male"
          aria-label="male"
          sx={{
            mr: 1,
            px: 2,
            height: "30px",
            borderRadius: "8px !important",
            "&:not(.Mui-selected)": {
              backgroundColor: "#ffffff14 !important",
              color: "white",
            },
          }}
        >
          <Avatar
            variant="square"
            alt="test avatar"
            src={Male}
            sx={{ height: "14px", width: "auto", objectFit: "contain" }}
          />
          <Typography sx={{ fontSize: "12px", ml: 1 }}>Male</Typography>
        </ToggleButton>
        <ToggleButton
          value="Female"
          aria-label="female"
          sx={{
            mr: 1,
            px: 2,
            height: "30px",
            borderRadius: "8px !important",
            "&:not(.Mui-selected)": {
              backgroundColor: "#ffffff14 !important",
              color: "white",
            },
          }}
        >
          <Avatar
            variant="square"
            alt="test avatar"
            src={Female}
            sx={{ height: "12px", width: "auto", objectFit: "contain" }}
          />
          <Typography sx={{ fontSize: "12px", ml: 1 }}>Female</Typography>
        </ToggleButton>
      </ToggleButtonGroup>
    </Box>
  );
}
