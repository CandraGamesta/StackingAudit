import React from "react";
import FormControl from "@mui/material/FormControl";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Box from "@mui/material/Box";
import { grey } from "@mui/material/colors";
import FavoriteBorder from "@mui/icons-material/FavoriteBorder";
import Favorite from "@mui/icons-material/Favorite";

export default function Characters() {
  const [state, setState] = React.useState({
    DealerZ: false,
    EnforcerZ: false,
    BodyguardZ: false,
    SpecialistZ: false,
  });

  const handleCharacterChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setState({
      ...state,
      [event.target.name]: event.target.checked,
    });
  };
  const { DealerZ, EnforcerZ, BodyguardZ, SpecialistZ } = state;
  return (
    <Box sx={{ display: "flex" }}>
      <FormControl sx={{ m: 3, mt: 0 }} component="fieldset" variant="standard">
        <FormGroup>
          <FormControlLabel
            control={
              <Checkbox
                checked={DealerZ}
                onChange={handleCharacterChange}
                name="DealerZ"
                icon={<FavoriteBorder />}
                checkedIcon={<Favorite />}
                sx={{
                  color: grey[200],
                  "&.Mui-checked": {
                    color: grey[100],
                  },
                }}
              />
            }
            label="DealerZ"
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={EnforcerZ}
                onChange={handleCharacterChange}
                name="EnforcerZ"
                sx={{
                  color: grey[200],
                  "&.Mui-checked": {
                    color: grey[100],
                  },
                }}
              />
            }
            label="EnforcerZ"
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={BodyguardZ}
                onChange={handleCharacterChange}
                name="BodyguardZ"
                sx={{
                  color: grey[200],
                  "&.Mui-checked": {
                    color: grey[100],
                  },
                }}
              />
            }
            label="BodyguardZ"
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={SpecialistZ}
                onChange={handleCharacterChange}
                name="SpecialistZ"
                sx={{
                  color: grey[200],
                  "&.Mui-checked": {
                    color: grey[100],
                  },
                }}
              />
            }
            label="SpecialistZ"
          />
        </FormGroup>
      </FormControl>
    </Box>
  );
}
