import React from "react";
import FormControl from "@mui/material/FormControl";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Box from "@mui/material/Box";
import { grey } from "@mui/material/colors";

export default function BlockSizes(props: any) {
  const [state, setState] = React.useState({
    Small: false,
    Medium: false,
    Large: false,
  });

  const handleCharacterChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setState({
      ...state,
      [event.target.name]: event.target.checked,
    });
  };
  const { Small, Medium, Large } = state;
  return (
    <Box sx={{ display: "flex" }}>
      <FormControl sx={{ m: 3, mt: 0 }} component="fieldset" variant="standard">
        <FormGroup>
          <FormControlLabel
            control={
              <Checkbox
                checked={Small}
                onChange={handleCharacterChange}
                name="Small"
                sx={{
                  color: grey[200],
                  "&.Mui-checked": {
                    color: "#8600d4",
                  },
                }}
              />
            }
            label="Small"
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={Medium}
                onChange={handleCharacterChange}
                name="Medium"
                sx={{
                  color: grey[200],
                  "&.Mui-checked": {
                    color: "#8600d4",
                  },
                }}
              />
            }
            label="Medium"
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={Large}
                onChange={handleCharacterChange}
                name="Large"
                sx={{
                  color: grey[200],
                  "&.Mui-checked": {
                    color: "#8600d4",
                  },
                }}
              />
            }
            label="Large"
          />
        </FormGroup>
      </FormControl>
    </Box>
  );
}
