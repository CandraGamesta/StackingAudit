import React from "react";
import FormControl from "@mui/material/FormControl";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Box from "@mui/material/Box";
import { grey } from "@mui/material/colors";
import Avatar from "@mui/material/Avatar";
import CommonIcon from "../../../assets/blackmarket/DopeZ-List/Common.png";
import RareIcon from "../../../assets/blackmarket/DopeZ-List/Rare.png";
import OGIcon from "../../../assets/blackmarket/DopeZ-List/OG.png";

export default function Rarity() {
  const [state, setState] = React.useState({
    Common: false,
    Rare: false,
    OG: false,
  });

  const handleCharacterChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setState({
      ...state,
      [event.target.name]: event.target.checked,
    });
  };
  const { Common, Rare, OG } = state;
  return (
    <Box sx={{ display: "flex" }}>
      <FormControl sx={{ m: 3, mt: 0 }} component="fieldset" variant="standard">
        <FormGroup>
          <FormControlLabel
            control={
              <Checkbox
                checked={Common}
                onChange={handleCharacterChange}
                name="Common"
                icon={
                  <Avatar
                    variant="square"
                    alt="test avatar"
                    src={CommonIcon}
                    sx={{ height: "24px", width: "24px" }}
                  />
                }
                sx={{
                  color: grey[200],
                  "&.Mui-checked": {
                    color: grey[100],
                  },
                }}
              />
            }
            label="Common"
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={Rare}
                onChange={handleCharacterChange}
                name="Rare"
                icon={
                  <Avatar
                    variant="square"
                    alt="test avatar"
                    src={RareIcon}
                    sx={{ height: "24px", width: "24px" }}
                  />
                }
                sx={{
                  color: grey[200],
                  "&.Mui-checked": {
                    color: grey[100],
                  },
                }}
              />
            }
            label="Rare"
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={OG}
                onChange={handleCharacterChange}
                name="OG"
                icon={
                  <Avatar
                    variant="square"
                    alt="test avatar"
                    src={OGIcon}
                    sx={{ height: "24px", width: "24px" }}
                  />
                }
                sx={{
                  color: grey[200],
                  "&.Mui-checked": {
                    color: grey[100],
                  },
                }}
              />
            }
            label="OG"
          />
        </FormGroup>
      </FormControl>
    </Box>
  );
}
