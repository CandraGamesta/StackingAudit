import React from "react";
import FormControl from "@mui/material/FormControl";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Box from "@mui/material/Box";
import { grey } from "@mui/material/colors";

export default function Characters(props: any) {
  /* const [state, setState] = React.useState({
    Basic: false,
    Landmark: false,
  });

  const handleCharacterChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setState({
      ...state,
      [event.target.name]: event.target.checked,
    });
  }; */
  const { Basic, Landmark } = props.blockzType;
  return (
    <Box sx={{ display: "flex" }}>
      <FormControl
        sx={{ my: 3, mt: 0, mb: 0 }}
        component="fieldset"
        variant="standard"
      >
        <FormGroup>
          <FormControlLabel
            control={
              <Checkbox
                checked={Basic}
                onChange={props.setBlockzType}
                name="Basic"
                sx={{
                  color: grey[200],
                  "&.Mui-checked": {
                    color: "#8600d4",
                  },
                }}
              />
            }
            label="Basic"
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={Landmark}
                onChange={props.setBlockzType}
                name="Landmark"
                sx={{
                  color: grey[200],
                  "&.Mui-checked": {
                    color: "#8600d4",
                  },
                }}
              />
            }
            label="Landmark"
          />
        </FormGroup>
      </FormControl>
    </Box>
  );
}
