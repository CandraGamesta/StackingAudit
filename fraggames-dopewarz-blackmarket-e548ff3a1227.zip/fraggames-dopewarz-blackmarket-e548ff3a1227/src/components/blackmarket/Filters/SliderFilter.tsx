import React from "react";
import Slider from "@mui/material/Slider";

export default function SliderFilter(props: any) {
  //const [price, setPrice] = React.useState<number[]>([0, 100]);

  const handlePriceChange = (event: Event, newValue: number | number[]) => {
    props.setPriceFilter(newValue as number[]);
  };
  return (
    <div>
      <Slider
        aria-label="Custom marks"
        value={props.priceFilter}
        max={props.maxPrice}
        onChange={handlePriceChange}
        color="secondary"
        valueLabelDisplay="on"
        sx={{
          width: "70%",
          fontFamily: "ThaleahFat",
          fontSize: "24px",
          "& .MuiSlider-thumb": {
            height: 14,
            width: 14,
            backgroundColor: "#97a4b0",
            borderRadius: 0,
            "&:before": {
              display: "none",
            },
          },
          "& .MuiSlider-valueLabel": {
            fontSize: 12,
            fontWeight: "normal",
            top: 45,
            backgroundColor: "unset",
            "&:before": {
              display: "none",
            },
            "& *": {
              background: "transparent",
            },
          },
        }}
      />
    </div>
  );
}
