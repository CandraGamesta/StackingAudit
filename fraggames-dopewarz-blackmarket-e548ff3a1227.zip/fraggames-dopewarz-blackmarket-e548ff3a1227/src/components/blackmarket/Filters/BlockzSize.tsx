import Box from "@mui/material/Box";
import ToggleButton from "@mui/material/ToggleButton";
import Typography from "@mui/material/Typography";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";

export default function BlockSize(props: any) {
  return (
    <Box sx={{ display: "flex" }}>
      <ToggleButtonGroup
        value={props.blockzSize}
        onChange={props.setBlockzSize}
        color="primary"
        sx={{
          "& .MuiToggleButtonGroup-grouped": {
            color: "primary",
            backgroundColor: "#8600d4 !important",
          },
        }}
      >
        <ToggleButton
          value="Small"
          aria-label="small"
          sx={{
            mr: 1,
            px: 2,
            height: "30px",
            borderRadius: "8px !important",
            "&:not(.Mui-selected)": {
              backgroundColor: "#ffffff14 !important",
              color: "white",
            },
          }}
        >
          <Typography sx={{ fontSize: "12px" }}>Small</Typography>
        </ToggleButton>
        <ToggleButton
          value="Medium"
          aria-label="medium"
          sx={{
            mr: 1,
            px: 2,
            height: "30px",
            borderRadius: "8px !important",
            "&:not(.Mui-selected)": {
              backgroundColor: "#ffffff14 !important",
              color: "white",
            },
          }}
        >
          <Typography sx={{ fontSize: "12px" }}>Medium</Typography>
        </ToggleButton>
        <ToggleButton
          value="Large"
          aria-label="large"
          sx={{
            mr: 1,
            px: 2,
            height: "30px",
            borderRadius: "8px !important",
            "&:not(.Mui-selected)": {
              backgroundColor: "#ffffff14 !important",
              color: "white",
            },
          }}
        >
          <Typography sx={{ fontSize: "12px" }}>Large</Typography>
        </ToggleButton>
      </ToggleButtonGroup>
    </Box>
  );
}
