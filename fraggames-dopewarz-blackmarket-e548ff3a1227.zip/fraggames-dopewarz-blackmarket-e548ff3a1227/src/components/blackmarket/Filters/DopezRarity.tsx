import Box from "@mui/material/Box";
import ToggleButton from "@mui/material/ToggleButton";
import Typography from "@mui/material/Typography";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import Avatar from "@mui/material/Avatar";
import Common from "../../../assets/blackmarket/Common-mini-selected.png";
import OG from "../../../assets/blackmarket/OG-mini-selected.png";
import Rare from "../../../assets/blackmarket/Rare-mini-selected.png";

export default function DopezRarity(props: any) {
  return (
    <Box sx={{ display: "flex" }}>
      <ToggleButtonGroup
        value={props.blockzSize}
        onChange={props.setBlockzSize}
        color="primary"
        sx={{
          "& .MuiToggleButtonGroup-grouped": {
            color: "primary",
            backgroundColor: "#8600d4 !important",
          },
        }}
      >
        <ToggleButton
          value="Common"
          aria-label="common"
          sx={{
            mr: 1,
            px: 1,
            height: "30px",
            borderRadius: "8px !important",
            "&:not(.Mui-selected)": {
              backgroundColor: "#ffffff14 !important",
              color: "white",
            },
          }}
        >
          <Avatar
            variant="square"
            alt="test avatar"
            src={Common}
            sx={{ height: "12px", width: "12px" }}
          />
          <Typography sx={{ fontSize: "12px", ml: 1 }}>Common</Typography>
        </ToggleButton>
        <ToggleButton
          value="Rare"
          aria-label="rare"
          sx={{
            mr: 1,
            px: 1,
            height: "30px",
            borderRadius: "8px !important",
            "&:not(.Mui-selected)": {
              backgroundColor: "#ffffff14 !important",
              color: "white",
            },
          }}
        >
          <Avatar
            variant="square"
            alt="test avatar"
            src={Rare}
            sx={{ height: "12px", width: "12px" }}
          />
          <Typography sx={{ fontSize: "12px", ml: 1 }}>Rare</Typography>
        </ToggleButton>
        <ToggleButton
          value="Og"
          aria-label="og"
          sx={{
            mr: 1,
            px: 1,
            height: "30px",
            borderRadius: "8px !important",
            "&:not(.Mui-selected)": {
              backgroundColor: "#ffffff14 !important",
              color: "white",
            },
          }}
        >
          <Avatar
            variant="square"
            alt="test avatar"
            src={OG}
            sx={{ height: "12px", width: "12px" }}
          />
          <Typography sx={{ fontSize: "12px", ml: 1 }}>Og</Typography>
        </ToggleButton>
      </ToggleButtonGroup>
    </Box>
  );
}
