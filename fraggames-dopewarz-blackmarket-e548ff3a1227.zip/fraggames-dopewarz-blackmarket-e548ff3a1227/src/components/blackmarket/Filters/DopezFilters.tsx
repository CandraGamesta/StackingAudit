import React from "react";
import Typography from "@mui/material/Typography";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ExpandMore from "src/assets/blackmarket/expand-more.png";
import SliderFilter from "./SliderFilter";
import DopezGender from "./DopezGender";
import DopezRarity from "./DopezRarity";
import { Box } from "@mui/material";
import Avatar from "@mui/material/Avatar";

export default function DopezFilters(props: any) {
  return (
    <React.Fragment>
      <Typography
        sx={{
          color: "#97a4b0",
          marginLeft: "0 !important",
          minWidth: "100% !important",
          marginBottom: "10px",
          fontFamily: "ThaleahFat",
          fontSize: "24px",
        }}
      >
        Filterz
      </Typography>
      <Accordion
        sx={{
          backgroundColor: "transparent",
          color: "#97a4b0",
          marginLeft: "10px !important",
          width: "98%",
          borderTop: "1px solid #0e1019",
          borderBottom: "1px solid #0e1019",
          borderRadius: "0 !important",
        }}
      >
        <AccordionSummary
          expandIcon={
            <Avatar
              alt="test avatar"
              src={ExpandMore}
              sx={{ height: "14px", width: "14px" }}
            />
          }
          sx={{
            flexDirection: "row-reverse",
          }}
        >
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "24px",
              color: "#97a4b0",
              pl: 2,
            }}
          >
            Price
          </Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ height: "70px", pt: 0 }}>
          <SliderFilter
            priceFilter={props.priceFilter}
            setPriceFilter={props.setPriceFilter}
            maxPrice={props.maxPrice}
          />
        </AccordionDetails>
      </Accordion>

      <Accordion
        sx={{
          backgroundColor: "transparent",
          color: "#97a4b0",
          marginLeft: "10px !important",
          width: "98%",
          borderTop: "1px solid #0e1019",
          borderBottom: "1px solid #0e1019",
          borderRadius: "0 !important",
        }}
      >
        <AccordionSummary
          expandIcon={
            <Avatar
              alt="test avatar"
              src={ExpandMore}
              sx={{ height: "14px", width: "14px" }}
            />
          }
          sx={{
            flexDirection: "row-reverse",
          }}
        >
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "24px",
              color: "#97a4b0",
              pl: 2,
            }}
          >
            Rarity
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <DopezRarity
            blockzSize={props.dopezRarity}
            setBlockzSize={props.setDopezRarity}
          />
        </AccordionDetails>
      </Accordion>
      <Accordion
        sx={{
          backgroundColor: "transparent",
          color: "#97a4b0",
          marginLeft: "10px !important",
          width: "98%",
          borderTop: "1px solid #0e1019",
          borderBottom: "1px solid #0e1019",
          borderRadius: "0 !important",
        }}
      >
        <AccordionSummary
          expandIcon={
            <Avatar
              alt="test avatar"
              src={ExpandMore}
              sx={{ height: "14px", width: "14px" }}
            />
          }
          sx={{
            flexDirection: "row-reverse",
          }}
        >
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "24px",
              color: "#97a4b0",
              pl: 2,
            }}
          >
            Gender
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <DopezGender
            blockzSize={props.dopezGender}
            setBlockzSize={props.setDopezGender}
          />
        </AccordionDetails>
      </Accordion>

      <Accordion
        sx={{
          backgroundColor: "transparent",
          color: "#97a4b0",
          marginLeft: "10px !important",
          width: "98%",
          borderTop: "1px solid #0e1019",
          borderBottom: "1px solid #0e1019",
          borderRadius: "0 !important",
        }}
      >
        <AccordionSummary
          expandIcon={
            <Avatar
              alt="test avatar"
              src={ExpandMore}
              sx={{ height: "14px", width: "14px" }}
            />
          }
          sx={{
            flexDirection: "row-reverse",
          }}
        >
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "24px",
              color: "#97a4b0",
              pl: 2,
            }}
          >
            Statz
          </Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ height: "70px", pt: 0 }}>
          <Box
            sx={{
              pb: 2,
            }}
          >
            <Typography
              sx={{
                fontFamily: "ThaleahFat",
                fontSize: "24px",
                color: "#97a4b0",
                pl: 2,
              }}
            >
              Power
            </Typography>
            <SliderFilter
              priceFilter={props.powerFilter}
              setPriceFilter={props.setPowerFilter}
              maxPrice={props.maxPower}
            />
          </Box>
          <Box
            sx={{
              pb: 2,
            }}
          >
            <Typography
              sx={{
                fontFamily: "ThaleahFat",
                fontSize: "24px",
                color: "#97a4b0",
                pl: 2,
              }}
            >
              Respect
            </Typography>
            <SliderFilter
              priceFilter={props.respectFilter}
              setPriceFilter={props.setRespectFilter}
              maxPrice={props.maxRespect}
            />
          </Box>
          <Box
            sx={{
              pb: 2,
            }}
          >
            {" "}
            <Typography
              sx={{
                fontFamily: "ThaleahFat",
                fontSize: "24px",
                color: "#97a4b0",
                pl: 2,
              }}
            >
              Skill
            </Typography>
            <SliderFilter
              priceFilter={props.skillFilter}
              setPriceFilter={props.setSkillFilter}
              maxPrice={props.maxSkill}
            />
          </Box>
          <Box
            sx={{
              pb: 2,
            }}
          >
            <Typography
              sx={{
                fontFamily: "ThaleahFat",
                fontSize: "24px",
                color: "#97a4b0",
                pl: 2,
              }}
            >
              Cunning
            </Typography>
            <SliderFilter
              priceFilter={props.cunningFilter}
              setPriceFilter={props.setCunningFilter}
              maxPrice={props.maxCunning}
            />
          </Box>
        </AccordionDetails>
      </Accordion>
    </React.Fragment>
  );
}
