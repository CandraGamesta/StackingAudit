import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Avatar from "@mui/material/Avatar";
import { Typography } from "@mui/material";
import CurrencyIcon from "src/assets/blackmarket/Currency-icon.png";
import { shortAddress } from "src/utils/text";
import { useHistory } from "react-router-dom";
export default function SalesHistory(props: any) {
  let historyBrowser = useHistory();
  return (
    <>
      <Grid container spacing={2} sx={{ margin: "5px" }}>
        <Typography
          sx={{
            fontFamily: "ThaleahFat",
            fontSize: "26px",
            color: "#97a4b0",
          }}
        >
          Salez History
        </Typography>
      </Grid>
      <Grid
        container
        alignItems="center"
        justifyContent="center"
        sx={{
          width: "100%",
          border: `3px solid #0b0c14`,
          borderRadius: 3,
          backgroundColor: "#040508",
          color: "#97a4b0",
          textAlign: "left",
        }}
      >
        <Grid item md={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
              m: 1,
            }}
          >
            <Typography sx={{ fontFamily: "ThaleahFat", fontSize: "18px" }}>
              Buyer
            </Typography>
          </Box>
        </Grid>
        <Grid item md={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
            }}
          >
            <Typography sx={{ fontFamily: "ThaleahFat", fontSize: "18px" }}>
              Seller
            </Typography>
          </Box>
        </Grid>
        <Grid item md={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
            }}
          >
            <Grid
              item
              textAlign="left"
              container
              direction="row"
              alignItems="left"
              justifyContent="left"
            >
              <Grid item pr={0.5} pt={0.9}>
                <Avatar
                  variant="square"
                  alt="test avatar"
                  src={CurrencyIcon}
                  sx={{ height: "12px", width: "12px" }}
                />
              </Grid>
              <Grid item>
                <Typography sx={{ pr: 1, fontFamily: "ThaleahFat", fontSize: "18px"}}>Drugz</Typography>
              </Grid>
            </Grid>
          </Box>
        </Grid>
        <Grid item md={3}>
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              flexDirection: "column",
            }}
          >
            <Typography sx={{ fontFamily: "ThaleahFat", fontSize: "18px" }}>
              Date
            </Typography>
          </Box>
        </Grid>

        {props.transactionHistory.map((history: any) => {
          return (
            <>
              <Grid item md={3}>
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "flex-start",
                    flexDirection: "column",
                    m:1,
                  }}
                >
                  <Typography
                    sx={{
                      color: "white",
                      fontSize: "12px",
                    }}
                    onClick={() => {
                      historyBrowser.push("/user/" + history.buyer);
                    }}
                  >
                    {shortAddress(history.buyer)}
                  </Typography>
                </Box>
              </Grid>
              <Grid item md={3}>
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "flex-start",
                    flexDirection: "row",
                  }}
                >
                  <Typography
                    sx={{
                      color: "white",
                      fontSize: "12px",
                    }}
                    onClick={() => {
                      historyBrowser.push("/user/" + history.seller);
                    }}
                  >
                    {shortAddress(history.seller)}
                  </Typography>
                </Box>
              </Grid>
              <Grid item md={3}>
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "flex-start",
                    flexDirection: "row",
                  }}
                >
                  <Typography
                    sx={{
                      color: "white",
                      fontSize: "12px",
                    }}
                  >
                    {history.price}
                  </Typography>
                </Box>
              </Grid>
              <Grid item md={3}>
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "flex-start",
                    flexDirection: "row",
                  }}
                >
                  <Typography
                    sx={{
                      color: "white",
                      fontSize: "12px",
                    }}
                  >
                    {new Date(history.createdAt).toDateString()}
                  </Typography>
                </Box>
              </Grid>
            </>
          );
        })}
      </Grid>
    </>
  );
}
