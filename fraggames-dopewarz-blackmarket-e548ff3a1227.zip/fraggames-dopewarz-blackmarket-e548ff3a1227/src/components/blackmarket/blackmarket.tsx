import React from "react";
import CssBaseline from "@mui/material/CssBaseline";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Avatar from "@mui/material/Avatar";
import DopezIcon from "../../assets/blackmarket/Dopez-icon.png";
import DOZIcon from "../../assets/blackmarket/DOZ-icon.png";
import LootboxIcon from "../../assets/blackmarket/LootboxIcon.png";
import BlockZIcon from "../../assets/blackmarket/BlockZ-icon.png";
import MarketplaceContent from "./marketplaceContent";
import ComingSoon from "./ComingSoon";
import { useLocation } from "react-router-dom";
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

export default function Blackmarket() {
  const [value, setValue] = React.useState(1);
  const location: any = useLocation();
  const [type, setType] = React.useState(location.state?.type);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    console.log(event);
    setValue(newValue);
  };
  React.useEffect(()=>{
    console.log("type in blackmarket is: "+ type );
    if(type === "Blockz"){
      setValue(1);
    }else if(type === "Dopez"){
      setValue(2);
    }else if(type === "Doz"){
      setValue(3);
    }
  },[type]);
  var sectionStyle = {
    marginTop: 0,
    color: "primary",
  };
  return (
    <React.Fragment>
      <CssBaseline />
      <div style={sectionStyle} className="pageMaxSize">
        <Tabs
          value={value}
          onChange={handleChange}
          color="secondary"
          indicatorColor="primary"
          variant="fullWidth"
          sx={{
            color: "white",
            "& .MuiTabs-indicator": {
              backgroundColor: "#8600d4",
              color: "#ffff",
            },
            "& .MuiTabs": {
              color: "#ffff",
            },
          }}
        >
          <Tab
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "24px",
            }}
            value={2}
            label="Dopez"
            icon={
              <Avatar
                variant="square"
                alt="test avatar"
                src={DopezIcon}
                sx={{ height: "24px", width: "24px" }}
              />
            }
            iconPosition="start"
            {...a11yProps(1)}
          />
          <Tab
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "24px",
            }}
            value={1}
            label="BlockZ"
            icon={
              <Avatar
                variant="square"
                alt="test avatar"
                src={BlockZIcon}
                sx={{ height: "24px", width: "24px" }}
              />
            }
            iconPosition="start"
            {...a11yProps(0)}
          />
          <Tab
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "24px",
            }}
            value={3}
            label="DOZ"
            icon={
              <Avatar
                variant="square"
                alt="test avatar"
                src={DOZIcon}
                sx={{ height: "24px", width: "24px" }}
              />
            }
            iconPosition="start"
            {...a11yProps(2)}
          />
          <Tab
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "24px",
            }}
            value={4}
            label="Lootboxes"
            icon={
              <Avatar
                variant="square"
                alt="test avatar"
                src={LootboxIcon}
                sx={{ height: "24px", width: "24px" }}
              />
            }
            iconPosition="start"
            {...a11yProps(3)}
          />
        </Tabs>
        <TabPanel value={value} index={2}>
          <MarketplaceContent type="Dopez" path="market" />
        </TabPanel>
        <TabPanel value={value} index={1}>
          <MarketplaceContent type="Blockz" path="market" />
        </TabPanel>
        <TabPanel value={value} index={3}>
        <MarketplaceContent type="Doz" path="market" />
        </TabPanel>
        <TabPanel value={value} index={4}>
          <ComingSoon />
        </TabPanel>
      </div>
    </React.Fragment>
  );
}
