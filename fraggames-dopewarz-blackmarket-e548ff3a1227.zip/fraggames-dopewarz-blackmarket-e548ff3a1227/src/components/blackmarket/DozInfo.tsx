import { useState } from "react";
import Grid from "@mui/material/Grid";
import { Typography } from "@mui/material";
import { useHistory } from "react-router-dom";
export default function DozInfo(props: any) {
  const [cards, setCards] = useState(props.cards);
  let history = useHistory();

  return (
    <>
      <Grid container spacing={1} sx={{ margin: "5px" }}>
        <Typography
          sx={{
            fontFamily: "ThaleahFat",
            fontSize: "26px",
            color: "#97a4b0",
          }}
        >
          About
        </Typography>
      </Grid>
      <Grid
        container
        alignItems="center"
        justifyContent="center"
        sx={{
          width: "100%",
          border: `3px solid #0b0c14`,
          borderRadius: 3,
          backgroundColor: "#040508",
          color: "white",
          textAlign: "left",
          p: 2,
        }}
      >
        <Grid item md={12} sm={12} xs={12}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
            }}
          >
            Drugz Capacity
          </Typography>
        </Grid>
        

        <Grid item md={12} sm={12} xs={12}>
          <Typography sx={{ fontSize: "14px" }}>
            {cards.nft.metadata.drugCapacity}
          </Typography>
        </Grid>
        

        
        <Grid item md={12} sm={12} xs={12} sx={{ pt: 3, overflow: "hidden" }}>
          <Typography
            sx={{
              fontFamily: "ThaleahFat",
              fontSize: "22px",
              color: "#97a4b0",
            }}
          >
            Owner
          </Typography>
        </Grid>

        <Grid
          item
          md={12}
          sm={12} xs={12}
          onClick={() => {
            history.push({
              pathname: "/user/" + cards.nft.ownerAddress,
              state: { type: "Doz" },
            });
            
          }}
        >
          <Typography sx={{ fontSize: "16px", cursor: "pointer", textOverflow: "ellipsis",
                          overflow: "hidden", }}>
            {cards.nft.ownerAddress}
          </Typography>
        </Grid>
      </Grid>
    </>
  );
}
