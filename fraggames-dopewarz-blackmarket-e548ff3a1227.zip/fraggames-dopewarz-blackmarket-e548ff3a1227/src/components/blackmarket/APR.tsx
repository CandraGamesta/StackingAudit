import React from "react";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Slide from "@mui/material/Slide";
import Button from "@mui/material/Button";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Typography } from "@mui/material";

function createData(timeFrame: string, roi: string, reward: number) {
  return { timeFrame, roi, reward };
}

let rows = [
  createData("1d", "0.082 %", 0.82),
  createData("7d", "0.57 %", 5.7),
  createData("30d", "2.46 %", 24.6),
  createData("365d", "30 %", 300),
];

export default function APR(props: any) {
  React.useEffect(() => {
    rows = [
      createData("1d", props.Apr.d1.percent + " %", props.Apr.d1.return),
      createData("7d", props.Apr.d7.percent + " %", props.Apr.d7.return),
      createData("30d", props.Apr.d30.percent + " %", props.Apr.d30.return),
      createData("365d", props.Apr.d365.percent + " %", props.Apr.d365.return),
    ];
  }, [props.Apr]);

  return (
    <div>
      <Dialog
        open={props.open}
        keepMounted
        onClose={props.handleClose}
        aria-describedby="alert-dialog-slide-description"
        sx={{
          "& .MuiDialog-paper": {
            backgroundColor: "#06070b !important",
            border: "1px solid grey",
            borderRadius: "25px",
          },
        }}
      >
        <DialogTitle>{"ROI"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
            <TableContainer component={Paper}>
              <Table
                sx={{ minWidth: 420, backgroundColor: "#06070b !important" }}
                aria-label="simple table"
              >
                <TableHead>
                  <TableRow>
                    <TableCell>Time Frame</TableCell>
                    <TableCell align="left">ROI</TableCell>
                    <TableCell align="left">Per $1000</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => (
                    <TableRow
                      key={row.timeFrame}
                      sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                    >
                      <TableCell component="th" scope="row">
                        {row.timeFrame}
                      </TableCell>
                      <TableCell align="left">{row.roi}</TableCell>
                      <TableCell align="left">{row.reward}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <Typography
              sx={{
                fontFamily: "ThaleahFat",
                fontSize: "18px",
                pt: 2,
                color: "#8600d4",
              }}
            >
              Disclaimer
            </Typography>
            <Typography
              sx={{
                fontFamily: "ThaleahFat",
                fontSize: "18px",
                pt: 2,
              }}
            >
              Calculated based on current rates. Compounding 288 times daily.
              Rates are estimates provided for your convenience only, and by no
              means represent guaranteed returns.
            </Typography>
          </DialogContentText>
        </DialogContent>
      </Dialog>
    </div>
  );
}
