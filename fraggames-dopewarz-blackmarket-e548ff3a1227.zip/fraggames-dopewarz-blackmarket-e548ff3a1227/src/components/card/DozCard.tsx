// Material
import Card from "@mui/material/Card";
import Box from "@mui/material/Box";
import CardContent from "@mui/material/CardContent";
import { CardActionArea } from "@mui/material";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";
import CurrencyIcon from "src/assets/blackmarket/Currency-icon.png";
import Avatar from "@mui/material/Avatar";
import { useHistory } from "react-router-dom";
import Chip from "@mui/material/Chip";
import DopezRarity from "./dopezRarity";
import Stack from "@mui/material/Stack";

const DozCard = (props: any) => {
  let history = useHistory();

  const { title, number, price, action, actionName } = props;

  function handleClick() {
    if (props.type === "Blockz") {
      history.push({
        pathname: "/blockz/" + props.nft._id,
        state: { card: props, type: props.type },
      });
    } else if (props.type === "Dopez") {
      history.push({
        pathname: "/dopez/" + props.nft._id,
        state: { card: props, type: props.type },
      });
    }
  }

  return (
    <Container>
      <div className="dopez-container">
        <Card className="dopez-card" onClick={handleClick}>
          <CardActionArea>
            <CardContent sx={{ height: "334px", width: "252px", p: 0 }}>
              <Typography
                variant="h6"
                sx={{
                  backgroundImage:
                    "linear-gradient(180deg, rgb(228,218,216) 0%, rgb(228,218,216) 30%, rgb(182,166,160) 50%)",
                  WebkitBackgroundClip: "text",
                  fontFamily: "PixeloidSansBold",
                  textShadow: "none",
                  p: 2,
                  pb: 0,
                }}
              >
                <Stack spacing={1} sx={{ p: 0 }}>
                  <Stack
                    direction="row"
                    spacing={7}
                    sx={{ flexWrap: "nowrap", justifyContent: "space-around" }}
                  >
                    <Box>
                      <Typography
                        noWrap
                        sx={{
                          width: "100px",
                          fontSize: "12px",
                          color: "white !important",
                          textOverflow: "ellipsis",
                        }}
                        align="left"
                      >
                        {props.nft.name}
                      </Typography>
                      {props.type == "Blockz" ? (
                        <Typography
                          sx={{
                            fontSize: "10px",
                            color: "#97a4b0 !important",
                            mt: 0.5,
                          }}
                          align="left"
                        >
                          New York
                        </Typography>
                      ) : (
                        ""
                      )}

                      
                    </Box>
                    <Chip
                      label={props.nft._id}
                      size="small"
                      sx={{
                        backgroundColor: "#ef8701",
                        color: "black",
                        p: 0,
                        fontSize: "12px",
                        maxWidth: "80px",
                        minWidth: "80px",
                        overflow: "hidden",
                        borderRadius: "8px",
                      }}
                    />
                  </Stack>
                  <Stack></Stack>
                </Stack>
              </Typography>

              {/* <Typography color="primary" fontFamily={"PixeloidSansBold"} variant="body2" sx={{ p: 0.5 }}>
                {" "}
                #{number}
              </Typography> */}
              <Box
                component="div"
                sx={{
                  width: "244px",
                  height: "232px",
                  ml: "4px",
                  mr: "4px",
                  display: "flex",
                  overflow: "hidden",
                  justifyContent: "center",
                  alignItems: "center",
                  my: 0.5,
                }}
              >
                <img
                  src={props.nft.image}
                  style={{
                    flex: "none",
                  }}
                ></img>
              </Box>

              <Grid
                item
                container
                direction="row"
                alignItems="center"
                justifyContent="center"
                sx={{ mt: 0.8 }}
              >
                <Grid item pr={0.5}>
                  <Avatar
                    variant="square"
                    alt="test avatar"
                    src={CurrencyIcon}
                    sx={{ height: "16px", width: "16px" }}
                  />
                </Grid>
                <Grid item>
                  <Typography
                    color="primary"
                    fontFamily={"PixeloidSansBold"}
                    variant="body2"
                    sx={{ p: 0.5, py: 0.1 }}
                  >
                    <Typography display="inline" color="primary">
                      {props.price}
                    </Typography>
                  </Typography>
                </Grid>
              </Grid>
            </CardContent>
          </CardActionArea>
        </Card>
      </div>
    </Container>
  );
};

export type ClaimCardProps = {
  title: string;
  number: number;
  price: number;
  actionName: string;
  action: () => void;
};

export default DozCard;
