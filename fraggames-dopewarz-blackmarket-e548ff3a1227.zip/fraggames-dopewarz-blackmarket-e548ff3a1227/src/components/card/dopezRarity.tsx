import OG from "../../assets/blackmarket/OG.png";
import Common from "../../assets/blackmarket/Common.png";
import Rare from "../../assets/blackmarket/Rare.png";
import Avatar from "@mui/material/Avatar";
export default function DopezRarity(props: any) {
  if (props.type == "Dopez") {
    if (props.rarity == "Og") {
      return (
        <Avatar
          variant="square"
          alt="test avatar"
          src={OG}
          sx={{ height: "16px", width: "16px" }}
        />
      );
    } else if (props.rarity == "Rare") {
      return (
        <Avatar
          variant="square"
          alt="test avatar"
          src={Rare}
          sx={{ height: "16px", width: "16px" }}
        />
      );
    } else if (props.rarity == "Common") {
      return (
        <Avatar
          variant="square"
          alt="test avatar"
          src={Common}
          sx={{ height: "16px", width: "16px" }}
        />
      );
    } else {
      return <></>;
    }
  } else {
    return <></>;
  }
}
