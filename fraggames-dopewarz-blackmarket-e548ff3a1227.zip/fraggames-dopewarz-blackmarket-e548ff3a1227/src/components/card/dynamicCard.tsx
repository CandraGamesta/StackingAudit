import BlockzCard from "./BlockzCard";
import ComingSoon from "../blackmarket/ComingSoon";

export default function DynamicCard(props: any) {
  if (props.type == "Dopez") {
    return <BlockzCard {...props.card} type={props.type} />;
  } else if (props.type == "Blockz") {
    return <BlockzCard {...props.card} type={props.type} />;
  } else if (props.type == "Doz"){
    return <BlockzCard {...props.card} type={props.type} />;
  }else {
    return <ComingSoon />;
  }
}
