// Material
import Card from "@mui/material/Card";
import Box from "@mui/material/Box";
import CardContent from "@mui/material/CardContent";
import { CardActionArea } from "@mui/material";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import DopezRarity from "./dopezRarity";
import Chip from "@mui/material/Chip";
import Stack from "@mui/material/Stack";
import Enforcer from "src/assets/blackmarket/enforcer.png";
import { useHistory } from "react-router-dom";

const ClaimCard = (props: any) => {
  let history = useHistory();

  const { title, number, price, action, actionName } = props;
  function handleClick() {
    history.push({
      pathname: "/dopez/" + props.nft._id,
      state: { card: props },
    });
  }

  return (
    <Container>
      <div className="dopez-container">
        <Card className="dopez-card" onClick={handleClick}>
          <CardActionArea>
            <CardContent sx={{ height: "334px", width: "252px", p: 0 }}>
              {/* <Typography
                sx={{
                  width: "100px",
                  fontSize: "12px",
                  color: "primary",
                  textOverflow: "ellipsis",
                  backgroundImage:
                    "linear-gradient(180deg, rgb(228,218,216) 0%, rgb(228,218,216) 30%, rgb(182,166,160) 50%)",
                  WebkitBackgroundClip: "text",
                  textShadow: "none",
                  pb: 2,
                  pt: 2,
                }}
              >
                {props.nft.name}
              </Typography> */}

              <Typography
                variant="h6"
                sx={{
                  backgroundImage:
                    "linear-gradient(180deg, rgb(228,218,216) 0%, rgb(228,218,216) 30%, rgb(182,166,160) 50%)",
                  WebkitBackgroundClip: "text",
                  fontFamily: "PixeloidSansBold",
                  textShadow: "none",
                  p: 2,
                  pb: 0,
                }}
              >
                <Stack spacing={1} sx={{ p: 0 }}>
                  <Stack
                    direction="row"
                    spacing={7}
                    sx={{ flexWrap: "nowrap", justifyContent: "space-around" }}
                  >
                    <Box>
                      <DopezRarity rarity={props.nft.rarity} />
                      <Typography
                        noWrap
                        sx={{
                          width: "100px",
                          fontSize: "12px",
                          color: "white !important",
                          textOverflow: "ellipsis",
                        }}
                        align="left"
                      >
                        {props.nft.name}
                      </Typography>
                    </Box>
                    <Chip
                      label={props.nft._id}
                      size="small"
                      sx={{
                        backgroundColor: "#ef8701",
                        color: "black",
                        p: 0,
                        fontSize: "12px",
                        maxWidth: "80px",
                        minWidth: "80px",
                        overflow: "hidden",
                        borderRadius: "8px",
                      }}
                    />
                  </Stack>
                  <Stack></Stack>
                </Stack>
              </Typography>

              {/* <Typography color="primary" fontFamily={"PixeloidSansBold"} variant="body2" sx={{ p: 0.5 }}>
                {" "}
                #{number}
              </Typography> */}
              <Box
                sx={{ width: "244px", height: "232px", ml: "4px", mr: "4px" }}
              >
                <img
                  src={Enforcer}
                  style={{
                    height: "100%",
                    width: "auto",
                  }}
                ></img>
              </Box>
              <Typography
                color="primary"
                fontFamily={"PixeloidSansBold"}
                variant="body2"
                sx={{ p: 0.5 }}
              >
                <Typography display="inline" color="primary">
                  ${price}
                </Typography>
              </Typography>
            </CardContent>
          </CardActionArea>
        </Card>
      </div>
    </Container>
  );
};

export type ClaimCardProps = {
  title: string;
  number: number;
  price: number;
  actionName: string;
  action: () => void;
};

export default ClaimCard;
