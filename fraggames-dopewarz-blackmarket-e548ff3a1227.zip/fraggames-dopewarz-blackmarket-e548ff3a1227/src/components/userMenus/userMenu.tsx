import React from "react";
import { useAuth } from "../hooks/web3Auth";
import Tooltip from "@mui/material/Tooltip";
import IconButton from "@mui/material/IconButton";
import Avatar from "@mui/material/Avatar";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import { useHistory } from "react-router-dom";
import GeneralButton from "../buttons/GeneralUseButton";
import { shortAddress } from "src/utils/text";
export default function UserMenu(props: any) {
  const history = useHistory();
  const { login, logout, account, chainId } = useAuth();
  const [anchorElUser, setAnchorElUser] = React.useState<null | HTMLElement>(
    null
  );
  const handleOpenUserMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorElUser(event.currentTarget);
  };
  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };
  const logOut = async () => {
    handleCloseUserMenu();
    await logout();
    history.push("/");
  };
  let displayAddress = shortAddress(account || "");
  return (
    <>
      <Tooltip title="Open settings">
        <GeneralButton
          disabled={!account}
          onClick={handleOpenUserMenu}
          solidDisabledText
          variant="extended"
        >
          {displayAddress}
        </GeneralButton>
        {/* <IconButton onClick={handleOpenUserMenu} sx={{ p: 0, pl: 2 }}>
                    <Avatar alt="Remy Sharp" src="/static/images/avatar/2.jpg" />
                </IconButton> */}
      </Tooltip>
      <Menu
        sx={{
          mt: "45px",
          color: "black",
          "& .MuiPaper-root": {
            backgroundColor: "#242735",
          },
        }}
        id="menu-appbar"
        anchorEl={anchorElUser}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        keepMounted
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        open={Boolean(anchorElUser)}
        onClose={handleCloseUserMenu}
        className="NavMenu"
      >
        {props.settings.map((setting: any, index: number) => (
          <MenuItem key={index} onClick={handleCloseUserMenu}>
            <Button href={setting.route}>
              <Typography textAlign="center">{setting.name}</Typography>
            </Button>
          </MenuItem>
        ))}
        <MenuItem key={props.settings.length} onClick={logOut}>
          <Typography textAlign="center" sx={{ p: "6px" }}>
            LOG OUT
          </Typography>
        </MenuItem>
      </Menu>
    </>
  );
}
