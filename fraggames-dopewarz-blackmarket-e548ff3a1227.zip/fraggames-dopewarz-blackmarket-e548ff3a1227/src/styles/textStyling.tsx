export const outlineShadow = (size: number, color: string) => {
  return `
    -${size}px -${size}px 0 ${color},
    0 -${size}px 0 ${color},
    ${size}px -${size}px 0 ${color},
    ${size}px 0 0 ${color},
    ${size}px ${size}px 0 ${color},
    0 ${size}px 0 ${color},
    -${size}px ${size}px 0 ${color},
    -${size}px 0 0 ${color}
  `;
};
