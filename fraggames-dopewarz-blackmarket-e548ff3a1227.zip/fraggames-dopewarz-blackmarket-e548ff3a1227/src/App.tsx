import "./App.css";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Blackmarket from "./components/blackmarket/blackmarket";
import Profile from "./components/blackmarket/profile";
import BlackmarketHeader from "./components/blackmarket/blackmarket-header";
import BlockzDetail from "./components/blackmarket/blockzDetail";
import AccountHistory from "./components/blackmarket/Account-History";
import PayoutsStatus from "./components/blackmarket/Payouts-Status";
import Staking from "./components/blackmarket/Staking";


// Material
import { ThemeProvider } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";

import theme from "src/styles/BaseTheme";
// web3
import { Web3ReactProvider } from "@web3-react/core";
import Web3 from "web3";

function getLibrary(provider: any, connector: any) {
  return new Web3(provider);
}

function App() {
  return (
    <>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Web3ReactProvider getLibrary={getLibrary}>
          <div className="App bg-position">
            <Router basename="/blackmarket">
              <BlackmarketHeader />
              <Switch>
                <Route path="/blackmarket">
                  <Blackmarket />
                </Route>
                <Route path="/accounthistory">
                  <AccountHistory />
                </Route>
                <Route path="/payoutsstatus">
                  <PayoutsStatus />
                </Route>
                <Route path="/staking">
                  <Staking />
                </Route>
                <Route path="/dopez/:id">
                  <BlockzDetail />
                </Route>
                <Route path="/blockz/:id">
                  <BlockzDetail />
                </Route>
                <Route path="/doz/:id">
                  <BlockzDetail />
                </Route>

                <Route path="/user/:id">
                  <Profile />
                </Route>
                <Route path="/">
                  <Blackmarket />
                </Route>
              </Switch>
            </Router>
          </div>
        </Web3ReactProvider>
      </ThemeProvider>
    </>
  );
}

export default App;
